# Script self-review rubric — PhimUS

Use this rubric after drafting or materially editing a script. Score the draft in front of you; tie deductions to a specific scene, line, or story detail. Apply the creator's brief rather than forcing every genre into one formula.

| Criterion | Max | Check |
|---|---:|---|
| Brief, genre, audience, and format fit | 10 | Correct language, approximate target length, premise, and approved details. |
| Opening hook and promise | 15 | Score every episode's first one or two spoken lines and opening beat for clarity, specific stakes, curiosity, natural delivery, and a promise that episode earns. Use the anchored scale below; do not award points for shock, a question mark, or loudness by themselves. |
| Conflict and escalation | 15 | Choices or misunderstandings change the situation, with believable consequences and authentic psychological friction. |
| Logic, cause and effect, and continuity | 15 | Actions fit what characters know; timeline, relationships, evidence, and prior events stay consistent. |
| Believable characters and vocal distinctiveness | 10 | Motives make sense; distinct vocal styles and subtext per character without stereotypes or flat literary prose. |
| Pacing and Micro-Retention | 10 | Every 10-second scene contains a reveal, escalation, or turn; remove dead air, repetition, and flat exposition. |
| Dialogue segmentation and cue timing | 10 | When timed cues are requested, split at actual speaker turns and give each cue a duration suited to its words, delivery, and pauses. Different lines should not receive the same fixed duration without a reason; keep cues within the scene and aligned with requested production prompts. |
| Dialogue subtext, flow, and TTS readiness | 10 | Dialogue acts on the scene rather than summarizing plot; lines feel complete, character-specific, and natural without a fixed word-count or speaking-rate target; natural breath pauses with punctuation; ready for TTS. |
| Climax and episodic Cliffhanger | 5 | Central tension delivers an earned turning point or closes on an urgent cliffhanger (knowledge gap, ultimatum, intrusion, unanswered accusation) compelling immediate next-episode viewing. |
| **Total** | **100** | |

## Scoring and revision rules

- Score the final revised draft, not the idea or the first draft. For every criterion, identify the exact line/scene that earns points and the specific evidence for each deduction. Give full points only when all checks are present; use roughly 75% of the maximum for a minor weakness, 50% for a clear weakness, 25% when mostly missing, and zero when absent or contradictory. Use whole numbers, add the rows exactly, and do not assume an unstated strength. Do not penalize the same flaw twice unless it causes two distinct problems. Do not reward length, shock, or plot density by itself.
- The overall passing threshold is **strictly above 90/100 (at least 91/100)** with no critical flaw; every short-form episode also needs an opening hook of at least 13/15, unless a quiet/slow-burn opening was requested. Score each episode separately. After no more than two passes, report the actual score and mark the draft not ready if either threshold is missed; never inflate the score.
- Name at most three priority issues, each with a location in the script and a concise repair direction. Fix those issues without changing the premise, intended ending, or approved constraints.
- Do not treat a slow burn, open ending, dry humor, or difficult character as a flaw when it is deliberate and fits the brief.
- Flag a critical flaw when the script violates a key instruction, materially contradicts established events, fails to pay off its central tension without an intentional open ending, or presents an unsupported real-world/trend claim as fact.
- Follow the pass threshold and revision limit in the main skill. After two revision passes, deliver the best version and identify any remaining issue rather than rewriting indefinitely.

## Opening hook scoring anchors — 15 points

Score the first one or two spoken lines/opening beat, not the title or a later reveal. Award points from these parts, then add them:

- **Immediate clarity (0–3):** viewers can picture what is happening without a long setup.
- **Specific conflict or stakes (0–4):** a concrete choice, loss, contradiction, or consequence gives a reason to care.
- **Curiosity (0–3):** the line opens a particular unanswered question; avoid generic “you won't believe” phrasing or a vague threat.
- **Natural spoken line (0–2):** concise, character-appropriate, easy to understand aloud; not a slogan or exposition dump.
- **Credible promise/payoff (0–3):** the episode actually develops or pays off what the opening implies; no bait-and-switch.

Use the total as a calibration: **13–15** compelling and specific across nearly all parts; **10–12** clear but with a noticeable weakness; **7–9** understandable but generic, low-stakes, or dependent on extra setup; **4–6** mostly exposition, confusion, or an unearned promise; **0–3** no usable hook or a misleading/unrelated opening. A short-form episode hook below 13 needs revision unless the creator requested a quiet/slow-burn opening.

## Hook window scoring: visual and dialogue

Do this for every short-form episode as part of self-review, whether or not the creator explicitly asks for a hook review. Score the image and spoken hook separately, each out of 15. Use only material visible or audible inside the requested interval; if no interval is specified, use 0–5 seconds. If a line or shot crosses the time boundary, score only the portion inside it. For untimed formats, use the first opening beat and first one or two spoken lines. Do not let a high score in one channel compensate for a score below 13 in the other. Mark a channel N/A when that element is intentionally absent. Later story content may be used only to confirm that the opening's implied promise is truthful; do not count later content as hook evidence.

For the **visual score**, use these anchors: immediate legibility (0–3); visible action, conflict, or stakes (0–4); visual curiosity (0–3); specificity and readability (0–2); fit with the episode's truthful promise/payoff (0–3). For the **spoken score**, use the five components in the hook anchors above. Report each score with its interval and brief evidence. Revise any requested/present channel below 13/15 unless a quiet/slow opening was deliberately chosen.

For a series, score each episode's opening hook independently. Judge the opening promise as a promise about that episode; score a closing tease separately as a next-episode hook and never use it to raise the opening-hook score.

## Reporting

When the creator requests scoring or a score table, show a complete table with every criterion, actual/max points, and concise evidence tied to a line or scene. Report the total, each episode's hook score, status as “ready” (at least 91/100, no critical flaw, and hook gate passed) or “not ready,” and up to three priority edits. For a hook-window review, show the exact interval and separate visual/dialogue scores. When dialogue is central, also report dialogue flow out of 10; for timed cues, report cue timing out of 10. If the creator asks to approve dialogue before JSON, omit scorecards unless they specifically request a score table; output only dialogue text, time cues, and silence notes, then wait. The score is an editorial estimate, not a prediction of views or virality.

## Cue timing and silence

- In a 10-second dialogue-drama scene, total time without spoken dialogue must be no more than 3 seconds, counting the opening gap, pauses between turns, and the tail. Music, ambience, and sound effects do not substitute for dialogue.
- Every 10-second scene must include at least one spoken turn unless the creator explicitly requests a silent scene. Use scene-relative start/end timecodes for each speaker turn; set cue timing from plausible performance and meaningful pauses instead of assigning identical durations mechanically.
- Verify that the sum of all no-dialogue intervals in each scene is at most 3 seconds and all cues fit within the scene. Do not infer a speaking rate from word count or recommend trimming natural lines to meet a numeric rate.

## Dialogue Quality and Micro-Retention Standards

- **Natural Sentence Pacing:** Judge length by character, intent, emotion, and performance. Do not impose a word-count or speaking-rate target; penalize only lines that are mechanically truncated or padded.
- **Subtext over Plot Narration:** Deduct points if characters speak like an exposition narrator or explain obvious facts. Every line must perform a dramatic action: confront, evade, guilt-trip, interrogate, or deceive.
- **Scene-level Retention Engine:** Verify that every 10-second scene carries at least one driver: Reveal, Escalate, or Turn. Deduct points for flat filler scenes.
- **Episodic Cliffhangers:** Assess whether episode endings employ one of the four retention hooks (Knowledge Gap, Ultimatum, Sudden Intrusion, Unanswered Accusation) to trigger immediate binge-watching.
