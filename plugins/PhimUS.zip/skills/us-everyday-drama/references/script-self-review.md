# Script self-review rubric — PhimUS

Use this rubric after drafting or materially editing a script. Score the draft in front of you; tie deductions to a specific scene, line, or story detail. Apply the creator's brief rather than forcing every genre into one formula.

| Criterion | Max | Check |
|---|---:|---|
| Brief, genre, audience, and format fit | 10 | Correct language, approximate target length, premise, and approved details. |
| Opening hook and promise | 15 | The opening creates a clear question or tension, fits the story, and is paid off or advanced. |
| Conflict and escalation | 15 | Choices or misunderstandings change the situation, with believable consequences. |
| Logic, cause and effect, and continuity | 15 | Actions fit what characters know; timeline, relationships, evidence, and prior events stay consistent. |
| Believable characters and U.S. audience fit | 15 | Motives make sense; setting and behavior feel locally plausible without stereotypes. |
| Pacing and retention | 15 | Each scene changes the situation or adds useful information; remove repetition and dead space. |
| Natural dialogue and TTS readiness | 10 | Spoken lines sound conversational, speakers are clear, words are pronounceable, and production notes stay out of narration. |
| Climax and ending payoff | 5 | The central tension has a result; twists and cliffhangers are planted unless the creator requested a different open ending. |
| **Total** | **100** | |

## Scoring and revision rules

- Score each criterion with a whole number from zero to its maximum: full points for clear success, a middle score for a specific weakness, and low points when the element is missing or contradictory. Do not reward length or plot density by itself.
- Name at most three priority issues, each with a location in the script and a concise repair direction. Fix those issues without changing the premise, intended ending, or approved constraints.
- Do not treat a slow burn, open ending, dry humor, or difficult character as a flaw when it is deliberate and fits the brief.
- Flag a critical flaw when the script violates a key instruction, materially contradicts established events, fails to pay off its central tension without an intentional open ending, or presents an unsupported real-world/trend claim as fact.
- Follow the pass threshold and revision limit in the main skill. After two revision passes, deliver the best version and identify any remaining issue rather than rewriting indefinitely.

## Reporting

By default, show only the total score, one to three key changes, and any remaining issue. Provide the complete rubric only when the creator asks for a detailed evaluation. The score is an editorial estimate, not a prediction of views or virality.
