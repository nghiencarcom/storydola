# U.S. Market Playbook: Setting, Voice, and Cultural Fit

Use this reference when a story needs cultural adaptation for U.S. viewers. It offers options, not a checklist. The main skill sets the writing workflow; this file supplies examples and adaptation cues.

## 1. Choose a grounded context

Before adding local color, identify whichever details matter to the story:

- **Place:** a named city/region if supplied; otherwise keep the setting broadly contemporary and do not guess a state from a stereotype.
- **Living arrangement:** homeowner, renter, roommate, multigenerational household, dorm, shared building, or another setup that fits the characters.
- **Audience:** age range, platform, genre, and whether viewers expect a first-person storytime, acted skit, or scripted series.
- **Community and routines:** work schedules, school, caregiving, commute, local weather, public events, or a holiday only when it affects the plot.
- **Relationship stakes:** money, privacy, boundaries, fairness, childcare, caregiving, reputation, work credit, or trust.

Do not stack familiar props—flags, pickup trucks, barbecue, church, baseball, Thanksgiving, or suburban lawns—to signal “American.” Use details because the characters live with them, not as decoration.

## 2. Plausible story engines

These are possibilities, not claims about what all Americans experience:

- **Neighbors and housing:** package delivered to the wrong door, noise in an apartment building, shared laundry, parking, maintenance requests, a property-line disagreement, or an HOA rule where a real HOA exists.
- **Family and blended households:** holiday hosting, caregiving, money between adult relatives, boundaries with in-laws, co-parenting schedules, stepfamily trust, or a promise made in front of the family group chat.
- **Work:** credit for an idea, shift swaps, return-to-office friction, a missed calendar invite, a team chat misunderstanding, competing deadlines, or a manager's uneven expectations. Do not invent labor-law or HR rules.
- **School and community:** pickup-line confusion, sports-team commitments, fundraising, a school group chat, a local volunteer event, or a disagreement about how adults respond to bullying. Avoid assuming every school has the same policies.
- **Dating and friendship:** a boundary crossed, a misread text, an ex at a gathering, a lie about plans, a friendship strained by money, or a difficult decision after infidelity. Do not turn revenge or privacy violations into a triumphant fix.
- **Everyday commerce:** a delayed delivery, a neighborhood sale, a service dispute, a social-media review, or an awkward small-business interaction. Keep consumer-rights claims accurate if the plot depends on them.

Pick one primary friction and one secondary complication. Too many institutions, holidays, slang cues, and side characters make a short script feel like a checklist.

## 3. Dialogue that sounds natural in American English

- Prefer contractions, concrete wording, and the characters' actual relationship to one another. Let people interrupt, hedge, or change the subject when that fits their personality; keep every line understandable on audio.
- Use everyday U.S. terms only when appropriate: “apartment,” “cell phone,” “parking lot,” “school pickup,” “group chat,” “mom,” “mother-in-law,” “stepdad,” “roommate,” “lease,” and “HOA.” Terminology can vary by person and region.
- Do not map Vietnamese forms of address word-for-word. For a narrator addressing viewers, possible choices include “you,” “everyone,” “folks,” or “you guys”; choose based on voice and audience. “Y'all” can be natural for some speakers and regions, but do not sprinkle it everywhere.
- Avoid fake dialect spelling and stereotype bundles. Region can come through one or two relevant words, place-specific routines, sentence rhythm, and what a character values; no phonetic accent is required.
- A funny line should arise from a specific person and moment, not from copying viral slang. For example: “By lunch, my neighbor had posted a photo of my trash can in the building chat. By dinner, the whole floor thought I was feeding raccoons.” Use a line like this as a model for rhythm, not as a reusable script.

## 4. Adaptation choices for a Vietnamese source story

Keep the emotional engine; rebuild the social mechanics:

| Source element | Adaptation question |
| --- | --- |
| Family title or honorific | Would the character use a first name, “Mom,” “Aunt…,” or a relationship label in this household? |
| Shared family obligation | What concrete promise, caregiving duty, money issue, or holiday plan creates the same pressure here? |
| Neighborhood authority | Is there an HOA, landlord, property manager, building chat, or no formal body at all? |
| School conflict | What school or team context fits the characters? Avoid assuming a specific policy. |
| Public embarrassment | Would the conflict happen in a group text, at work, during a gathering, or online? Who can actually see it? |
| Humor or wordplay | What joke would this character make in natural English? Replace the joke rather than translating its wording. |

Keep the relationship and emotional stakes legible. If a Vietnamese custom remains central, establish it briefly instead of pretending it is a U.S. custom.

## 5. Trends and audience fit

Internet language changes quickly and varies by platform, age, and community. Before using a phrase as a current U.S. trend, verify it from recent U.S.-relevant examples. A phrase that is broadly understood may be dated rather than current; a global meme may not fit a particular U.S. audience. Keep trend research and citations outside the spoken script, and use only the phrases that fit the characters.
