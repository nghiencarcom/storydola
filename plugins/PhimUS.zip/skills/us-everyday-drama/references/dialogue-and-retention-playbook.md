# Dialogue & Retention Playbook — U.S. Everyday Drama

This guide outlines practical techniques, character voice mechanics, and retention formulas to write compelling, binge-worthy AI drama scripts for U.S. audiences.

---

## 1. Dialogue Is Action, Not Exposition

Characters in high-retention short drama do not summarize the plot or explain background events. Every spoken line is a psychological weapon or shield.

### The 3 Layers of Dialogue:
1. **Text (Surface):** The literal words spoken.
2. **Subtext (Internal):** Hidden fears, resentment, concealed agendas, or unspoken guilt.
3. **Action (Intent):** What the character is actively trying to do to the other person (interrogate, deflect, guilt-trip, test loyalty, intimidate, or evade).

### Flat Plot Narration vs. Sharp Subtext-Driven Dialogue:
| Situation | Flat / Exposition Dump (Avoid) | Sharp Subtext / High Retention (Encouraged) | Dynamic & Subtext Analysis |
| :--- | :--- | :--- | :--- |
| **Disputed joint account withdrawal** | *"I saw thirty-five thousand dollars was withdrawn from our joint account to pay for your machine."* | *"Thirty-five thousand dollars out of our savings... Mark told me that money was locked in a fixed CD. Care to explain why his 'CD' is sitting in your garage?"* | **Confrontational & Exposing:** Nails the husband's lie directly, forcing an immediate showdown without whining. |
| **Parent/In-law defending an overreach** | *"I bought this because our family needs it, you don't need to complain about it."* | *"I built this business twenty years before you ever set foot in this house. Since when do I need permission from my daughter-in-law to save it?"* | **Guilt-tripping / Turf defense:** Asserts seniority and emotional leverage to put the newcomer on the defensive. |
| **Conflict-avoidant spouse caught in the middle** | *"Please stop fighting, both of you. I will work overtime to pay back the difference."* | *"Mom's blood pressure is already through the roof today... can you not turn every single family decision into a federal lawsuit?"* | **Deflecting / Gaslighting:** Makes the spouse look unreasonable to avoid addressing his own deception. |

---

## 2. Flexible Sentence Length and Conversational Flow

### A. Let the Thought and Performance Set the Length
- Everyday American speech has rhythm, contractions, irony, and conversational cadence. A line can be short or long depending on the character's intent, emotion, relationship, language, and performance.
- Do not impose a word-count or words-per-second target. Preserve complete thoughts without stretching them; when dialogue needs more room, adjust the beat or split at a natural turn when the format allows.

### B. Preserve the Thought Without Cutting to a Word Count
- Avoid fragmenting one connected thought into mechanical pieces when that weakens the intent or emotion. Short lines are also natural when a character needs emphasis, an outburst, a command, or a refusal.
  * *Choppy example:* *"He lied. She took the money. I am leaving now. Bye."*
  * *Complete conversational example:* *"You told me that money was safe, Mark, but your mother just showed me the receipt."*

### C. Voice Model (TTS) Cadence Controls
- **Commas `,`:** Mark natural breath or thought changes; do not divide lines by a fixed word count.
- **Ellipsis `...`:** Insert micro-hesitations or suppressed emotions (*"He said... he signed the deed over... three weeks ago."*).
- **Em-dashes `—`:** Capture mid-sentence interruptions or rapid emotional pivots (*"I've supported you for ten years — but you don't get to gamble our kids' tuition."*).

---

## 3. Micro-Retention in 10-Second Scenes

Audience retention drops sharply if a scene is purely functional or stationary.

### A. The Golden 3-Second Hook
- Start in media res. The first 3 seconds must deliver an immediate visual or vocal clash—no slow establishing shots, no morning greetings, no casual chat.

### B. The 10-Second Scene Retention Engine
Every 10-second scene must contain at least one of these three elements:
1. **Reveal:** A new clue, opened phone screen, hidden bank statement, or overheard whisper.
2. **Escalate:** Raised stakes, an impossible trade-off, or an ultimatum.
3. **Turn:** An unexpected counter-move or psychological reversal that shatters the other character's assumptions.

---

## 4. Four High-Retention Cliffhanger Formulas

To compel viewers to immediately watch the next episode:
1. **The Knowledge Gap:** A hidden document or photo is revealed in the final frame before anyone can explain it (*"Why is your signature on this foreclosure notice?"*).
2. **The Ultimatum:** A ticking clock or ultimatum with zero room to negotiate (*"You have until 8 AM tomorrow to put that money back, or HR gets this recording."*).
3. **The Sudden Intrusion:** An unexpected knock, a third person walking through the door, or a sudden call right as the truth is about to be spoken.
4. **The Unanswered Accusation:** A chilling, precise question that leaves the opposing character completely speechless as the screen fades out.
