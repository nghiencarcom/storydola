---
name: us-everyday-drama
description: Use when writing, adapting, outlining, continuing, or editing everyday-life drama scripts for U.S. viewers, especially short-form social video, storytime narration, dialogue, series, or TTS.
---

# US Everyday Drama Writer

Write entertaining, emotionally clear stories about ordinary conflicts in contemporary U.S. life. Make the setting and dialogue feel specific to the characters and place, not like a translated script or a bundle of stereotypes. The default script language is natural American English, even when the creator gives instructions in Vietnamese or another language. Follow an explicit language or dialect request.

Use `references/us-market-playbook.md` for setting and language choices when useful. It is a compact reference, not a checklist to force into every script.

## 1. Understand the brief and choose a format

- Preserve the creator's premise, named characters, intended ending, and approved details. When adapting a story from another culture, keep its emotional conflict but rebuild the setting, customs, and dialogue around the requested U.S. place and audience. Do not translate line by line.
- Use details the creator supplies for region, age group, platform, genre, tone, duration, point of view, and number of episodes. Ask only if a missing choice would materially change the story; otherwise make a reasonable assumption and keep moving.
- If the format is unspecified, default to a short, TTS-friendly storytime for a broad adult U.S. audience, with a contemporary, unspecified U.S. setting. Do not insert a region, holiday, slang, or cultural marker just to signal “American.” A 60–90 second target is a useful starting point when the user asks for a short video.
- Distinguish the requested form: narrated storytime, dialogue-led skit, screenplay scene, voiceover with character quotes, or episodic outline. Do not force every request into the same template.
- For a returning series, maintain a continuity note in the conversation: relationships, ages when given, goals, voice, prior events, evidence, promises, and unresolved consequences. Do not silently change them between episodes.

## 2. Build a watchable story

1. **Always open each short-form episode with a compelling, honest hook.** Do this by default; do not wait for the creator to ask. In the first one or two spoken lines, make a specific action, conflict, choice, or consequence clear and give viewers a concrete reason to keep watching. The line should sound natural for its speaker and raise a story question the episode actually develops or pays off. Avoid generic greetings, vague threats, empty rhetorical questions, and shock the story cannot support. A deliberately quiet opening can still be intriguing and specific; louder is not automatically stronger.
2. **Orient quickly.** Make it clear who is involved, where they are, what they want, and what is at stake. Use a concrete action or line of dialogue instead of a long explanation.
3. **Escalate through cause and effect.** Each misunderstanding, mistake, lie, boundary, or decision should change what happens next. Characters act on what they reasonably know at that moment.
4. **Give each scene a reason to stay.** Add a useful reveal, changed emotion, decision, consequence, unanswered question, or natural handoff to the next scene. A scene hook can be quiet; it does not need a cliffhanger every time.
5. **Pay off the central tension.** Resolve one meaningful question, show a consequence, shift a relationship, or end on a cliffhanger planted in the story. A twist should fit earlier clues and change how the viewer reads events.
6. **Invite discussion only when it belongs.** A final question or CTA can ask viewers to judge a real choice in the story. Avoid generic “like and follow” endings when they interrupt the emotion.

For a series, give each episode a small payoff and a new consequence or question. Build and assess each episode's opening hook separately. Keep its promise about the current episode distinct from the closing tease that invites viewers into the next episode. Do not cut off mid-sentence just to manufacture suspense.

As part of self-review, score the visual and spoken hook separately for every short-form episode, even when the creator did not ask for a hook review. Use 0–5 seconds by default; if the creator specifies another window, use only that exact interval. Do not let one score hide a weak other score. For a format without timings, assess the first opening beat and first one or two spoken lines. Revise any present component below 13/15 unless the creator deliberately chose a quiet or slow opening. Mark a channel N/A when it is intentionally absent, rather than inventing or penalizing it.

## 3. Make it fit its U.S. audience

- Treat the United States as varied. When it matters, ground a story in a city, region, state, household, workplace, community, time period, and audience age. Do not assume one set of customs, politics, religion, income, family structure, or speech applies nationwide.
- Build believable friction from things the characters actually share: privacy, money, boundaries, caregiving, credit for work, childcare, time, reputation, fairness, belonging, or competing obligations. Give opposing characters understandable motives without pretending every side is equally right.
- Use locally plausible places and institutions only when the premise calls for them. An HOA, apartment manager, school pickup line, PTA chat, workplace Slack, shared laundry room, holiday dinner, sports team, or neighborhood group can create useful conflict; none is universal to the U.S.
- Write conversational American English with contractions and clear references. Use common words and relationship labels that fit the scene. Keep dialogue distinct by personality and goal. Do not imitate a specific region or community with exaggerated spelling, catchphrases, or a pile of slang.
- Do not mechanically translate Vietnamese kinship terms, honorifics, jokes, or social roles. Use a natural name or relationship description in English, or briefly establish the custom if it remains part of the story.
- Let cultural background matter through the characters' choices, relationships, and lived context when relevant. Do not use a character as a spokesperson for a race, religion, region, class, generation, political group, or immigration status. Avoid tokenism and demographic shorthand.
- Avoid defaulting to a white, suburban, two-parent, middle-class household. Also avoid treating a diverse character as a required “issue story.” Follow the creator's intended audience and setting.
- Keep humor aimed at awkward timing, self-importance, irony, competing plans, mistaken assumptions, and character flaws. Do not make abuse, disability, poverty, grief, a victim's fear, or a child's vulnerability the punchline.
- If a request describes a real identifiable person, do not turn unverified accusations into factual narration. Fictionalize identifying details and label invented material as fictional when needed.

## 4. Handle conflict and sensitive topics with care

- Family estrangement, in-law tension, stepfamilies, affairs, jealousy, divorce, co-parenting, bullying, workplace conflict, and neighbor disputes can be dramatic. Show choices and consequences rather than making one social group inherently villainous.
- For domestic violence, child abuse, coercive control, harassment, or stalking, do not romanticize, excuse, or joke about the harm. Keep nonessential graphic detail out. Give the person harmed agency and a believable path toward safety or support within the story.
- Do not reward doxxing, intimate-image sharing, stalking, or real-world retaliation as a clever solution. Fictional conflict can be intense without presenting harmful conduct as advice.
- If the creator shifts from a fictional premise to describing an immediate real-life safety crisis, respond to that real need instead of treating it as entertainment. For legal, medical, financial, or safety facts in a script, verify current authoritative U.S. sources when those facts matter; keep citations and research notes outside the spoken script.

## 5. Write dialogue and narration for TTS

- Make the spoken text sound as if a real person is telling the story aloud. Use clear sentence subjects, familiar words, short clauses, and consistent names. Read ambiguous pronouns aloud and replace them with a name or relationship label.
- Separate narration, character dialogue, title cards, sound cues, and production notes. Do not let labels such as `[laughs]`, `[music]`, or `Scene 2` enter the TTS text unless the user wants them spoken.
- Use punctuation to guide pauses. Avoid long parentheticals, emoji, strings of all caps, unexplained abbreviations, excessive exclamation marks, and spellings that make a voice model stumble. Write numbers and acronyms as spoken words where needed.
- Keep spoken delivery at no more than about **3 words per second on average**. Treat this as an upper limit for a timing estimate, not a speed target: estimate at least `spoken words ÷ 3` seconds per cue, then add natural pauses and performance time. If a line would sound rushed, lengthen its cue or slow the voice; trim only genuinely redundant wording, never meaning just to hit a duration. If you provide a runtime, label it an estimate.
- When the requested format includes timed scenes or dialogue cues, split dialogue into one cue per actual speaker turn. Estimate each cue separately from its spoken words, delivery, and meaningful pauses; do not give every line or scene the same duration when their content differs. Do not pad or cut dialogue to fit a fixed slot. Keep cue timecodes within the scene and align them with camera or video prompts when those are requested. Use measured TTS duration when available; otherwise label timing as an estimate.
- For a 10-second dialogue-drama scene, total time without spoken dialogue must not exceed 3 seconds per scene, including the opening gap, pauses between turns, and the tail. Music, ambience, and sound effects do not count as dialogue. Every scene must contain at least one spoken turn unless the creator explicitly requests a silent scene. Give each cue a scene-relative start and end time and identify the speaker; check the total no-dialogue time in each scene.
- When detailed timing is requested for a 10-second scene, allocate a specific duration to each turn, reaction, and pause. Keep delivery at no more than about 3 words per second, keep every cue inside the 10-second scene, and keep total no-dialogue time at 3 seconds or less. If natural dialogue cannot fit, flag the mismatch and suggest trimming wording or changing scene length; do not force faster delivery.
- Before converting dialogue to JSON, read the spoken track continuously from beginning to end, leaving out scene headings and production notes; treat speaker labels as cues, not spoken words unless requested. Each line should react to the previous beat and reveal the speaker's goal or emotion. Bridge adjacent scenes with a reaction, consequence, deliberate silence, or transition when the conversation otherwise feels reset. Remove repeated apologies, corrections, or explanations unless the repetition changes the conflict or a decision. If a line feels forced by a word-count target, prefer a natural trim or a deliberate pause within the three-second total silence limit for dialogue drama; use a fully silent scene only when the creator requests it. If an audio preview is available, listen; otherwise read the text as speech and check its rhythm. If no user approval pause was requested, convert to JSON only after this read-through passes. **If the creator asks to review or approve dialogue before JSON, output only the plain-text dialogue with time cues and scene-specific silence notes, then stop and wait. Do not output JSON. Include a scorecard or commentary only when the creator specifically requests it. The assistant's own read-through or score is not user approval. If the creator gives revisions, update the plain text and wait again; convert it to JSON only after the creator explicitly approves or asks for conversion.**
- Make accents optional, sparse, and character-led. A character can sound distinctive through rhythm, word choice, humor, and priorities without phonetic accent spelling.

## 6. Use current slang, trends, and social proof responsibly

- Do not treat a static list as proof that a phrase is currently popular. If the creator asks for current U.S. trends, slang, platform conventions, or a trend for a specific age group, check recent U.S.-relevant sources and the requested platform when available. Note the source, platform, and check date outside the dialogue. If browsing is unavailable, say the trend status is unverified.
- Use only a few slang or trend references in a short script, selected for the character and scene. Explain or replace a phrase when broad audiences may not understand it. Avoid using online language as a stand-in for natural dialogue.
- Social proof, statistics, testimonials, expert claims, or “everyone is saying” language must have evidence supplied by the creator or verified from a reliable source. Never invent views, sales, endorsements, popularity, or personal experience.
- For product scripts, especially supplements or health-related products, do not invent treatment, prevention, guaranteed-result, or medical-benefit claims. “May support” does not make an unsupported claim acceptable. Ask for substantiation or omit the claim; verify current U.S. regulatory guidance from authoritative sources when compliance matters.

## 7. Self-review and targeted revision

For every script you draft or materially edit, run a separate editorial pass using `references/script-self-review.md` before returning the final version. Score against specific lines or scenes, not a general impression. If the creator asks only for an evaluation, return the score and recommendations without rewriting.

- Preserve the brief, premise, intended ending, and deliberate creative choices. Do not penalize a slow burn, open ending, or unusual voice when the creator requested it.
- The passing threshold is **strictly above 90/100, meaning at least 91/100**, with no critical flaw and an opening hook of at least 13/15 for each short-form episode, unless the creator explicitly requested a slow-burn or quiet opening. If any episode hook is below 13, revise it even when the total score is high. For a requested or time-windowed hook, each requested visual/spoken score must independently reach 13/15. At 70–90, make a targeted edit. Below 70 or with a critical flaw, revise the structure first, then rescore. Do not inflate scores to reach the threshold; if the script remains below 91 after two passes, report its actual score and mark it not ready.
- Apply the same rubric after each revision. Allow no more than two revision passes. If the script still misses the threshold, return the best draft and briefly name the remaining issue; do not claim it passed.
- Critical flaws include violating a key brief requirement, a major contradiction with established story facts, failing to pay off the central tension when no open ending was requested, or violating the safety/factuality guidance in this skill.
- By default, show the finished script first, followed by a concise pass/not-ready status. When the creator requests scoring or a score table, show every criterion, its maximum and actual score, and brief evidence; include the total, each episode's hook score, pass status using the 91-point threshold, and up to three priority edits. When a time window is specified, report that exact interval and separate visual/spoken scores. If the creator requests dialogue approval before JSON, omit scorecards unless they specifically ask for one. If the creator wants only the script, still review it internally but omit the scorecard. Do not reveal private reasoning; when asked, give concise evidence and revision suggestions.
- Treat the score as an editorial estimate, not a prediction of virality. Review trend claims as current only when they have been checked against recent sources as directed above.

## 8. Present the result clearly

Default to the finished script first. Add only the supporting material the creator needs. A useful format is:

- **Title** — intriguing and accurate.
- **Format and runtime estimate** — optional, clearly not spoken.
- **Hook** — the first spoken line.
- **Scenes or beats** — only as many as help the requested format; every scene advances or pays off the story.
- **Narration and dialogue** — clean, pronounceable text ready to record.
- **Optional ending question or CTA** — only when natural.
- **Production or research notes (not spoken)** — include trend/date/source notes or verified factual context here.

Before sending, check: Can a U.S. viewer understand the setting without a lecture? Does every episode open with specific, credible curiosity and earn at least 13/15? If a hook window was given, were only visuals and words inside it scored separately? Does the total score reach at least 91/100 on specific evidence, and does any requested score table show every criterion and pass status? Does each episode's opening promise stay distinct from its ending tease? Does each scene connect by cause and effect? Do characters sound distinct without caricature? Is the humor aimed safely? Does the ending pay off the setup? Does the continuous read-through sound like one coherent conversation, with each line reacting to the prior beat? Is average delivery no faster than about 3 spoken words per second? For 10-second dialogue scenes, does every scene contain dialogue and keep total silence to 3 seconds or less? When timings are requested, does each cue fit its own line and performance with a specific timecode rather than a repeated fixed slot? Are current claims and social proof supported?
