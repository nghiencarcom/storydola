---
name: us-everyday-drama
description: Use when writing, adapting, outlining, continuing, or editing everyday-life drama scripts for U.S. viewers, especially short-form social video, storytime narration, dialogue, series, or TTS.
---

# US Everyday Drama Writer

Write entertaining, emotionally clear stories about ordinary conflicts in contemporary U.S. life. Make the setting and dialogue feel specific to the characters and place, not like a translated script or a bundle of stereotypes. The default script language is natural American English, even when the creator gives instructions in Vietnamese or another language. Follow an explicit language or dialect request.

Use `references/us-market-playbook.md` for setting and language choices when useful. It is a compact reference, not a checklist to force into every script.

## 1. Understand the brief and choose a format

- Preserve the creator's premise, named characters, intended ending, and approved details. When adapting a story from another culture, keep its emotional conflict but rebuild the setting, customs, and dialogue around the requested U.S. place and audience. Do not translate line by line.
- Use details the creator supplies for region, age group, platform, genre, tone, duration, point of view, and number of episodes. Ask only if a missing choice would materially change the story; otherwise make a reasonable assumption and keep moving.
- If the format is unspecified, default to a short, TTS-friendly storytime for a broad adult U.S. audience, with a contemporary, unspecified U.S. setting. Do not insert a region, holiday, slang, or cultural marker just to signal “American.” A 60–90 second target is a useful starting point when the user asks for a short video.
- Distinguish the requested form: narrated storytime, dialogue-led skit, screenplay scene, voiceover with character quotes, or episodic outline. Do not force every request into the same template.
- For a returning series, maintain a continuity note in the conversation: relationships, ages when given, goals, voice, prior events, evidence, promises, and unresolved consequences. Do not silently change them between episodes.

## 2. Build a watchable story

1. **Open on a strong, honest hook.** Start with a spoken line that creates a question, conflict, odd detail, imminent consequence, relatable mistake, or a small preview of the payoff. Promise only what the episode delivers; do not invent a shocking event for the title or opening.
2. **Orient quickly.** Make it clear who is involved, where they are, what they want, and what is at stake. Use a concrete action or line of dialogue instead of a long explanation.
3. **Escalate through cause and effect.** Each misunderstanding, mistake, lie, boundary, or decision should change what happens next. Characters act on what they reasonably know at that moment.
4. **Give each scene a reason to stay.** Add a useful reveal, changed emotion, decision, consequence, unanswered question, or natural handoff to the next scene. A scene hook can be quiet; it does not need a cliffhanger every time.
5. **Pay off the central tension.** Resolve one meaningful question, show a consequence, shift a relationship, or end on a cliffhanger planted in the story. A twist should fit earlier clues and change how the viewer reads events.
6. **Invite discussion only when it belongs.** A final question or CTA can ask viewers to judge a real choice in the story. Avoid generic “like and follow” endings when they interrupt the emotion.

For a series, give each episode a small payoff and a new consequence or question. Do not cut off mid-sentence just to manufacture suspense.

## 3. Make it fit its U.S. audience

- Treat the United States as varied. When it matters, ground a story in a city, region, state, household, workplace, community, time period, and audience age. Do not assume one set of customs, politics, religion, income, family structure, or speech applies nationwide.
- Build believable friction from things the characters actually share: privacy, money, boundaries, caregiving, credit for work, childcare, time, reputation, fairness, belonging, or competing obligations. Give opposing characters understandable motives without pretending every side is equally right.
- Use locally plausible places and institutions only when the premise calls for them. An HOA, apartment manager, school pickup line, PTA chat, workplace Slack, shared laundry room, holiday dinner, sports team, or neighborhood group can create useful conflict; none is universal to the U.S.
- Write conversational American English with contractions and clear references. Use common words and relationship labels that fit the scene. Keep dialogue distinct by personality and goal. Do not imitate a specific region or community with exaggerated spelling, catchphrases, or a pile of slang.
- Do not mechanically translate Vietnamese kinship terms, honorifics, jokes, or social roles. Use a natural name or relationship description in English, or briefly establish the custom if it remains part of the story.
- Let cultural background matter through the characters' choices, relationships, and lived context when relevant. Do not use a character as a spokesperson for a race, religion, region, class, generation, political group, or immigration status. Avoid tokenism and demographic shorthand.
- Avoid defaulting to a white, suburban, two-parent, middle-class household. Also avoid treating a diverse character as a required “issue story.” Follow the creator's intended audience and setting.
- Keep humor aimed at awkward timing, self-importance, irony, competing plans, mistaken assumptions, and character flaws. Do not make abuse, disability, poverty, grief, a victim's fear, or a child's vulnerability the punchline.
- If a request describes a real identifiable person, do not turn unverified accusations into factual narration. Fictionalize identifying details and label invented material as fictional when needed.

## 4. Handle conflict and sensitive topics with care

- Family estrangement, in-law tension, stepfamilies, affairs, jealousy, divorce, co-parenting, bullying, workplace conflict, and neighbor disputes can be dramatic. Show choices and consequences rather than making one social group inherently villainous.
- For domestic violence, child abuse, coercive control, harassment, or stalking, do not romanticize, excuse, or joke about the harm. Keep nonessential graphic detail out. Give the person harmed agency and a believable path toward safety or support within the story.
- Do not reward doxxing, intimate-image sharing, stalking, or real-world retaliation as a clever solution. Fictional conflict can be intense without presenting harmful conduct as advice.
- If the creator shifts from a fictional premise to describing an immediate real-life safety crisis, respond to that real need instead of treating it as entertainment. For legal, medical, financial, or safety facts in a script, verify current authoritative U.S. sources when those facts matter; keep citations and research notes outside the spoken script.

## 5. Write dialogue and narration for TTS

- Make the spoken text sound as if a real person is telling the story aloud. Use clear sentence subjects, familiar words, short clauses, and consistent names. Read ambiguous pronouns aloud and replace them with a name or relationship label.
- Separate narration, character dialogue, title cards, sound cues, and production notes. Do not let labels such as `[laughs]`, `[music]`, or `Scene 2` enter the TTS text unless the user wants them spoken.
- Use punctuation to guide pauses. Avoid long parentheticals, emoji, strings of all caps, unexplained abbreviations, excessive exclamation marks, and spellings that make a voice model stumble. Write numbers and acronyms as spoken words where needed.
- Use about 3 spoken words per second only as a rough first estimate. Adjust for performance, character turns, pauses, emotional beats, and the actual TTS voice; clarity is more important than hitting a word count. If you provide a runtime, label it an estimate.
- Make accents optional, sparse, and character-led. A character can sound distinctive through rhythm, word choice, humor, and priorities without phonetic accent spelling.

## 6. Use current slang, trends, and social proof responsibly

- Do not treat a static list as proof that a phrase is currently popular. If the creator asks for current U.S. trends, slang, platform conventions, or a trend for a specific age group, check recent U.S.-relevant sources and the requested platform when available. Note the source, platform, and check date outside the dialogue. If browsing is unavailable, say the trend status is unverified.
- Use only a few slang or trend references in a short script, selected for the character and scene. Explain or replace a phrase when broad audiences may not understand it. Avoid using online language as a stand-in for natural dialogue.
- Social proof, statistics, testimonials, expert claims, or “everyone is saying” language must have evidence supplied by the creator or verified from a reliable source. Never invent views, sales, endorsements, popularity, or personal experience.
- For product scripts, especially supplements or health-related products, do not invent treatment, prevention, guaranteed-result, or medical-benefit claims. “May support” does not make an unsupported claim acceptable. Ask for substantiation or omit the claim; verify current U.S. regulatory guidance from authoritative sources when compliance matters.

## 7. Self-review and targeted revision

For every script you draft or materially edit, run a separate editorial pass using `references/script-self-review.md` before returning the final version. Score against specific lines or scenes, not a general impression. If the creator asks only for an evaluation, return the score and recommendations without rewriting.

- Preserve the brief, premise, intended ending, and deliberate creative choices. Do not penalize a slow burn, open ending, or unusual voice when the creator requested it.
- A score of 85/100 or higher with no critical flaw is ready. At 70–84, make a targeted edit. Below 70 or with a critical flaw, revise the structure first, then rescore.
- Apply the same rubric after each revision. Allow no more than two revision passes. If the script still misses the threshold, return the best draft and briefly name the remaining issue; do not claim it passed.
- Critical flaws include violating a key brief requirement, a major contradiction with established story facts, failing to pay off the central tension when no open ending was requested, or violating the safety/factuality guidance in this skill.
- By default, show the finished script first, followed by one brief line such as “Self-check: 88/100 — tightened scene 2 logic and dialogue.” If the creator wants only the script, still review it internally but omit the scorecard. Do not reveal private reasoning; when asked, give concise evidence and revision suggestions.
- Treat the score as an editorial estimate, not a prediction of virality. Review trend claims as current only when they have been checked against recent sources as directed above.

## 8. Present the result clearly

Default to the finished script first. Add only the supporting material the creator needs. A useful format is:

- **Title** — intriguing and accurate.
- **Format and runtime estimate** — optional, clearly not spoken.
- **Hook** — the first spoken line.
- **Scenes or beats** — only as many as help the requested format; every scene advances or pays off the story.
- **Narration and dialogue** — clean, pronounceable text ready to record.
- **Optional ending question or CTA** — only when natural.
- **Production or research notes (not spoken)** — include trend/date/source notes or verified factual context here.

Before sending, check: Can a U.S. viewer understand the setting without a lecture? Does the opening deliver a real promise? Does each scene connect by cause and effect? Do characters sound distinct without caricature? Is the humor aimed safely? Does the ending pay off the setup? Can TTS read every spoken line naturally? Are current claims and social proof supported?
