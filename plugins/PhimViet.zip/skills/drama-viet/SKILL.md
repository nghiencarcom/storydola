---
name: drama-viet
description: Use when writing, outlining, continuing, or editing Vietnamese everyday-life drama scripts, narration, or dialogue for short videos, series, or TTS. Especially useful for neighbor conflicts, in-law tension, domestic violence, blended families, workplace drama, infidelity, and other relatable household, relationship, or community stories.
---

# Biên kịch drama đời thường Việt Nam

Viết những câu chuyện giải trí, dễ hiểu và gần gũi với đời sống người Việt. Ưu tiên lời kể có thể đọc thành tiếng hoặc đưa vào TTS ngay, nhân vật có lý do hành động, tình tiết nối nhau tự nhiên và cảm xúc đọng lại sau câu chuyện. Tham khảo `references/dialogue-and-retention-playbook.md` để áp dụng các kỹ thuật chuyên sâu về lời thoại có subtext, ma trận khẩu khí nhân vật, nhịp câu linh hoạt và cấu trúc giữ chân vi mô.

## 1. Hiểu yêu cầu và chọn hướng viết

- Giữ nguyên ý tưởng, nhân vật, kết thúc và chi tiết mà người dùng đã chốt. Nếu họ đưa bản nháp, hãy sửa đúng mục tiêu thay vì tự đổi chủ đề.
- Xác định định dạng, khán giả, nền tảng, độ dài, giọng kể, số tập và kiểu kết thúc nếu người dùng đã nêu. Nếu thiếu, tự chọn phương án phù hợp và nói rõ giả định ngắn gọn khi nó ảnh hưởng đến kết quả.
- Mặc định có thể viết một tập video ngắn độc lập, kể bằng tiếng Việt phổ thông pha khẩu ngữ vừa phải. Không hỏi dồn một danh sách thông tin; chỉ hỏi khi thiếu dữ kiện khiến không thể chọn hướng truyện hợp lý.
- Với chuỗi tập, giữ một sổ liên tục nội bộ về tuổi, quan hệ, cách xưng hô, mong muốn, bí mật, sự kiện đã xảy ra và các chi tiết còn dang dở. Không tự ý đổi tính cách hay làm mất vật chứng, lời hứa, mốc thời gian đã thiết lập.
- Có thể đưa thêm một câu hỏi tương tác hoặc lời mời theo dõi khi hợp với câu chuyện. Không ép CTA, twist, lời bình của người kể hay bằng chứng xã hội vào mọi tập.

## 2. Dựng câu chuyện và nhịp giữ chân

1. **Mọi tập video ngắn đều phải mở bằng hook cuốn hút và khơi tò mò.** Đây là mặc định, không cần người dùng nhắc. Trong một hoặc hai câu thoại đầu (hoặc 0–3 giây đầu), cho thấy ngay hành động, xung đột, lựa chọn hoặc hậu quả cụ thể, ném người xem vào ngay giữa tâm bão (in media res). Tuyệt đối tránh chào hỏi chung chung, mở đầu bằng hội thoại xã giao hay giải thích hoàn cảnh dài dòng. Mở lặng vẫn có thể hấp dẫn nếu hình ảnh chứa đựng sự căng thẳng và chi tiết lạ; nói lớn hay giật gân không tự động làm hook hay hơn.
2. **Quy luật giữ chân vi mô (Micro-Retention) trong từng cảnh 10 giây.** Không một cảnh nào được bằng phẳng hay chỉ dùng để dẫn chuyện. Mỗi cảnh phải chứa ít nhất một trong ba động lực giữ chân:
   - **Tiết lộ mới (Reveal):** Xuất hiện một bằng chứng, vật phẩm, tin nhắn hay thông tin làm đảo lộn góc nhìn.
   - **Leo thang xung đột (Escalate):** Cái giá phải trả tăng lên, sức ép thời gian siết lại hoặc ranh giới bị phá vỡ.
   - **Đổi chiều / Phản ứng bất ngờ (Turn / Reaction):** Nhân vật có phản ứng, câu trả lời hoặc quyết định trái ngược hoàn toàn dự đoán của đối phương.
3. **Tăng xung đột theo quan hệ nhân quả và tâm lý.** Mỗi hiểu lầm, lời nói dối, sự phòng thủ hoặc quyết định phải làm tình thế biến đổi. Cho nhân vật phản ứng từ chính nỗi sợ và điều họ biết lúc đó; không tạo biến cố ngẫu nhiên chỉ để kéo dài kịch bản.
4. **Kết nối các cảnh bằng chuyển giao kịch tính.** Cảnh sau không chỉ tiếp nối vật lý mà phải là hệ quả cảm xúc của cảnh trước. Tận dụng nguyên tắc "Show, Don't Tell" kết hợp góc máy AI: để hành động, ánh mắt, bàn tay siết chặt hay đồ vật rơi vỡ gánh bớt phần thị giác, giúp câu thoại sau đó cô đọng và có sức nặng ngàn cân.
5. **Kho vũ khí Cliffhanger cuối tập (Episodic Retention Anchors).** Với chuyện nhiều tập, cuối mỗi tập phải để lại một cái móc lôi kéo người xem bấm tập kế tiếp ngay lập tức. Phân biệt rõ: hook đầu tập là lời hứa cho chính tập đó, còn móc kết tập là câu hỏi/hậu quả mở ra cho tập sau. Tuyệt đối không cắt ngang câu thoại nửa chừng một cách giả tạo; hãy dùng 4 công thức Cliffhanger sắc bén:
   - *Lỗ hổng thông tin (The Knowledge Gap):* Một bằng chứng, tin nhắn hoặc sự thật động trời vừa lộ ra ở giây cuối cùng nhưng chưa kịp giải thích.
   - *Tối hậu thư & Hạn chót (The Ultimatum):* Đặt ra một thời hạn chót không thể thương lượng (*"Trước tám giờ sáng mai, nếu tiền không về tài khoản, con sẽ tự tay đưa đơn này lên phường"*).
   - *Nhân tố bất ngờ xuất hiện (The Sudden Intrusion):* Sự xuất hiện đột ngột của người thứ ba, tiếng gõ cửa dồn dập hoặc cuộc gọi từ người vắng mặt đúng giây phút sinh tử.
   - *Câu hỏi dồn vào chân tường (The Unanswered Accusation):* Một câu hỏi bóc trần động cơ thực sự khiến đối phương câm nín, màn hình chuyển cảnh trước khi có câu trả lời.
6. **Rà lại phần gieo và gặt.** Twist cần được gợi trước và làm thay đổi cách hiểu sự việc; không dùng cú lật vô cớ. Tránh kết luận đạo lý dài dòng. Khi phù hợp, kết bằng một câu hỏi tranh luận bám sát lựa chọn của nhân vật.

Trong lượt tự rà soát, luôn chấm riêng hook hình ảnh và lời thoại cho từng tập video ngắn, kể cả khi người dùng không nhắc đến hook. Mặc định xét 0–5 giây; nếu người dùng chỉ rõ khoảng khác, chỉ dùng đúng khoảng đó. Không để điểm cao của phần này bù cho phần yếu của phần kia. Với định dạng không có timecode, xét nhịp mở cảnh và một hoặc hai câu thoại đầu. Phần hiện diện dưới 13/15 phải sửa, trừ khi người dùng chủ ý chọn cách mở chậm hoặc lặng. Nếu một kênh cố ý không có, ghi N/A thay vì tự bịa hoặc trừ điểm.

## 3. Nhân vật, chất Việt và hài hước

- Cho mỗi nhân vật chính một mong muốn cụ thể, một điểm mù hoặc nỗi lo, và cách nói riêng. Nhân vật có thể ích kỷ, khó chịu hay sai nhưng cần có lý do dễ hiểu; tránh biến cả nhóm thành một người tốt và một kẻ ác phẳng lì.
- Xây mâu thuẫn từ chuyện người xem dễ nhận ra: ranh giới riêng tư, tiền bạc, việc nhà, thể diện, lời đồn, trông con, tiếng ồn, hiểu lầm trong nhóm chat hoặc khác biệt thế hệ. Chọn chi tiết phù hợp địa phương và hoàn cảnh đã nêu; đừng gom mọi định kiến vùng miền, nghề nghiệp, giới tính hay tầng lớp vào một nhân vật.

### Drama công sở và quan hệ tình cảm

- Với drama công sở, có thể khai thác chia việc, tranh công, bị quên ghi nhận đóng góp, đổi ca, deadline, thiên vị, đồn đoán hoặc hiểu lầm trong nhóm chat. Làm rõ vị trí, quyền hạn và điều mỗi người muốn. Nếu có quấy rối, bắt nạt hay phân biệt đối xử, không biến người bị hại thành trò cười.
- Với ngoại tình hoặc phản bội, tập trung vào niềm tin, lựa chọn, ranh giới và hệ quả. Cho nhân vật có động cơ riêng mà không đánh đồng lỗi của các bên. Không dùng xâm phạm riêng tư, phát tán ảnh thân mật, bạo lực hay trả thù làm phần thưởng hoặc lời khuyên.

### Kho đề tài đời thường để gợi ý

Chọn một vài mâu thuẫn hợp với nhân vật; đây là kho gợi ý, không phải mô tả rằng gia đình hay cộng đồng Việt nào cũng giống nhau.

- Gia đình nhiều thế hệ: chăm cha mẹ lớn tuổi, tiền sinh hoạt, việc nhà, nuôi dạy con, anh chị em, con riêng, chia tài sản/thừa kế, giỗ chạp hoặc tiền phúng viếng.
- Hàng xóm và nơi ở: tiếng ồn, thú cưng, rác, chỗ đỗ xe, hành lang và khu vực chung, phí sinh hoạt, nhóm chat cư dân, chủ nhà-người thuê, tiền cọc hoặc ở ghép.
- Trường học và phụ huynh: quỹ lớp, thu chi thiếu rõ ràng, quà cáp, hoạt động lớp, áp lực thành tích, hiểu lầm trong nhóm chat và cách người lớn xử lý bắt nạt.
- Công sở: chia việc, ghi nhận công sức, đổi ca, phe nhóm, lời đồn, quản lý thiên vị, áp lực thời hạn và ranh giới giữa đồng nghiệp.
- Tình cảm: ngoại tình, người cũ, ghen tuông, tiền chung, lời hứa, tha thứ hay chia tay và cách cùng chăm con sau đổ vỡ.
- Mua bán và đời sống số: livestream, lời quảng bá, chốt đơn, hàng giao khác kỳ vọng, đổi trả, đánh giá, bình luận lan truyền và chuyện riêng bị đưa lên mạng.
- Cưới hỏi, ma chay, Tết và việc cộng đồng: tiền mừng/phúng viếng, phân công chuẩn bị, chuyện thăm hỏi, đóng góp hoặc khác biệt phong tục giữa các gia đình. Chỉ dùng chi tiết phong tục khi hợp bối cảnh; không coi một cách làm là chuẩn chung cho mọi vùng.
- Xây dựng **Khẩu khí nhân vật riêng biệt (Character Vocal Signature)**: Tránh để các nhân vật nói cùng một giọng văn viết chuẩn mực.
  + *Người lớn tuổi / Mẹ chồng:* Nói bóng gió, tự ái, viện dẫn công lao, thể diện gia đình, dùng câu hỏi tu từ gây sức ép đạo đức (*"Nuôi con lớn chừng này, giờ sắm cái máy may lo cho cái nhà này cũng phải làm đơn xin phép con dâu?"*).
  + *Người trẻ / Nàng dâu:* Gãy gọn, rành mạch, dùng dữ kiện thực tế (tiền bạc, giấy tờ, tin nhắn) làm vũ khí, giữ khoảng cách lịch sự nhưng sắc lạnh.
  + *Người chồng kẹt ở giữa:* Lúng túng, né tránh mâu thuẫn, nói nước đôi, dùng từ ngữ xoa dịu tạm bợ làm tình hình rối thêm.
  + *Người làm ăn / Em gái / Hàng xóm:* Nhanh mồm nhanh miệng, thực dụng, mang hơi thở đời sống và toan tính cá nhân rõ ràng.
- Tạo hài bằng quan sát đời thường, tương phản, nhịp ngắt, lời nói nước đôi, sự tự tin sai chỗ, hiểu lầm hợp lý và chi tiết quay lại đúng lúc. Hãy để tình huống hoặc tính cách tạo tiếng cười; không cần biến mọi câu thành câu đùa.
- Tranh cãi nên đến từ lựa chọn mà mỗi bên có lý lẽ, hệ quả và giới hạn riêng. Không bịa sự thật, kích động thù ghét hay cố tình làm nhục một nhóm người chỉ để câu bình luận.
- Dùng xưng hô nhất quán theo tuổi tác, quan hệ, vùng miền và giọng nhân vật. Các cách gọi như “mình”, “mấy bà”, “mấy anh em”, “mấy bác” hợp với người kể đang trò chuyện trực tiếp với khán giả; không tự động nhét chúng vào mọi nhân vật. Những cách gọi tạo màu sắc như “bổn tọa”, “ngộ”, “tại hạ”, “lão phu”, “bần đạo”, “bần tăng” chỉ dùng khi hợp vai hoặc là một nét hài có chủ ý. Không trộn tùy tiện khiến người nghe khó hiểu.
- Ưu tiên tiếng Việt đời thường tự nhiên, câu có nhạc tính và từ ngữ quen thuộc. Có thể dùng khẩu ngữ hoặc phương ngữ theo yêu cầu, nhưng vừa đủ để tạo sắc thái và không làm khán giả ngoài vùng khó theo dõi.

## 4. Chủ đề tổn thương và nhân vật dễ bị tổn thương

Có thể viết về bạo lực gia đình, trẻ em, con riêng/con ghẻ, bắt nạt, kiểm soát hoặc xung đột gia đình. Giữ thái độ tôn trọng và để hành vi gây hại có hậu quả rõ ràng.

- Không biến bạo lực, sợ hãi, thương tích hoặc sự bất lực của nạn nhân thành punchline, trò câu view hay bằng chứng rằng người gây hại “thương quá hóa ghen”. Không lãng mạn hóa việc kiểm soát, đe dọa hoặc ép buộc.
- Nếu cần chất hài, đặt nó ở sự vụng về, thói sĩ diện, lời đồn hoặc tình huống phụ; không nhắm vào nạn nhân hay trẻ em. Có thể cho nhân vật bị hại giữ tiếng nói, tìm hỗ trợ và đưa ra lựa chọn an toàn theo mạch truyện.
- Tránh miêu tả bạo lực đồ họa không cần thiết. Không dùng tổn thương của trẻ em như một chi tiết gây sốc đơn thuần.
- Nếu người dùng lấy cảm hứng từ người thật, không tự thêm cáo buộc như sự thật; nên hư cấu hóa và bỏ chi tiết nhận dạng riêng tư khi cần.

## 5. Viết lời kể và lời thoại cho TTS

- **Quy tắc Subtext (Lời thoại ngầm) & Chống kể lể sự vụ (Anti-Exposition):** Lời thoại là hành động (tấn công, thăm dò, phòng thủ, lấp liếm, tống tiền cảm xúc), không phải bản tin thời sự tóm tắt cốt truyện. Cấm để nhân vật nói huỵch toẹt mọi suy nghĩ hay giải thích sự tình cho khán giả hiểu. Áp dụng nguyên tắc 3 tầng: *Text* (nói ra ngoài) - *Subtext* (nghĩ ngầm bên trong) - *Action* (hành vi thực sự nhắm vào đối phương).
- **Độ dài câu thoại & nhịp điệu đời sống:**
  + Không có số từ chuẩn cho một câu thoại. Câu ngắn hay dài tùy ý đồ, giọng nhân vật, cảm xúc, ngôn ngữ và cách diễn; giữ trọn ý khi cần, dùng câu ngắn khi đúng nhịp.
  + Không băm nhỏ ý thành câu cụt máy móc, nhưng cũng không kéo dài câu chỉ để đạt độ dài mong muốn. Không áp mục tiêu số từ hoặc tốc độ từ/giây.
- **Điều khiển nhịp đọc TTS có hồn và tự nhiên:**
  + Dùng dấu phẩy `,` để ngắt nơi người nói cần lấy hơi hoặc chuyển ý; không chia câu theo số từ cố định.
  + Dùng dấu chấm lửng `...` để thể hiện sự ngập ngừng, che giấu hoặc nghẹn ngào.
  + Dùng dấu gạch ngang `—` cho những cú ngắt lời bất ngờ hoặc bẻ ngoặt cảm xúc.
  + Tách hoàn toàn tiêu đề cảnh, chỉ dẫn dựng, âm thanh và ghi chú diễn xuất khỏi phần lời đọc TTS. Không để các cụm như “[cười]”, “[nhạc căng thẳng]” lọt vào phần văn bản đọc.
- **Thời lượng thoại và diễn xuất trong cảnh 10 giây:**
  + Căn cue theo cách diễn có chủ đích, ngôn ngữ, nhịp câu và khoảng nghỉ thực tế; không quy đổi số từ sang thời lượng bằng tốc độ cố định.
  + Nếu lời thoại tự nhiên không vừa nhịp cảnh, hãy điều chỉnh beat hoặc chia ở điểm chuyển ý phù hợp khi định dạng cho phép; không thúc giọng, cắt cụt câu hay thêm lời cho vừa con số.
  + Với drama thoại có cảnh 10 giây: tổng thời gian không có lời thoại trong mỗi cảnh không quá 3 giây (tính cả đầu cảnh, giữa các lượt và đuôi cảnh). Mỗi cảnh phải có ít nhất một lượt thoại, trừ khi người dùng chủ ý yêu cầu cảnh im lặng.
- **Quy trình duyệt thoại văn bản trước khi chuyển JSON:**
  + Trước khi chuyển lời thoại sang JSON, hãy đọc liên tục từ đầu đến cuối không có tiêu đề cảnh; mỗi câu phải phản ứng với diễn biến trước và mang mục đích/cảm xúc rõ ràng.
  + **Nếu người dùng yêu cầu duyệt thoại trước JSON, chỉ xuất bản thoại chữ cùng cue thời gian và ghi chú khoảng im lặng theo từng cảnh, rồi dừng chờ phản hồi. Không xuất JSON.** Việc assistant tự đọc hoặc tự chấm không phải là người dùng duyệt. Chỉ chuyển sang JSON sau khi người dùng nói rõ đã duyệt hoặc yêu cầu chuyển đổi.

## 6. Sự thật, social proof và nội dung sản phẩm

- Với quảng cáo hoặc nội dung phi hư cấu, chỉ thêm social proof như số liệu, đánh giá khách hàng, lời chứng thực hay mức độ phổ biến khi người dùng cung cấp căn cứ có thể kiểm tra. Không tự chế khảo sát, doanh số, giấy phép, chứng nhận, chuyên gia hay trải nghiệm khách hàng. Trong truyện hư cấu, lời đồn hoặc ý kiến đám đông có thể là tình tiết, nhưng không trình bày chúng như testimonial hay dữ kiện ngoài đời thật.
- Với thực phẩm chức năng và sản phẩm tương tự, không tự tuyên bố chữa, điều trị, phòng bệnh, bảo đảm kết quả hoặc hiệu quả tuyệt đối. Chỉ dùng nội dung có căn cứ trong tài liệu người dùng cung cấp. Từ “hỗ trợ” không tự làm cho một tuyên bố trở thành có căn cứ; nếu thiếu tài liệu, bỏ tuyên bố đó hoặc hỏi xin nguồn trước khi đưa vào kịch bản.
- Không tự khẳng định sản phẩm đã được cấp phép, kiểm nghiệm, chứng minh lâm sàng hay đáp ứng quy định nếu không có giấy tờ trong ngữ cảnh. Không biến nội dung quảng bá thành lời kể trải nghiệm thật nếu trải nghiệm đó không được cung cấp.
- CTA, lời bình cá nhân và twist là lựa chọn biên tập. Chỉ dùng khi chúng hợp giọng kể và có ích cho câu chuyện.


## 7. Dùng trend và tiếng lóng có chọn lọc

Khi người dùng muốn “bắt trend”, dùng từ lóng hoặc tăng chất mạng xã hội, hãy mở `references/trend-vocabulary.md` để chọn cách dùng và `references/trend-bank-2005-2026.md` để tra kho từ/cụm tiếng Việt, quốc tế và meme theo giai đoạn. Kho từ là tư liệu rộng, không phải bảng xếp hạng trend hiện tại.

- Nếu yêu cầu nói rõ “đang hot”, “trend tuần này/tháng này” hoặc chỉ một nền tảng/nhóm tuổi, kiểm tra nguồn gần thời điểm đăng trên đúng nền tảng và ở Việt Nam. Ưu tiên bài đăng/video gần đây có tương tác thực, trang theo dõi xu hướng hoặc bài tổng hợp có ngày cập nhật; đối chiếu thêm nguồn thứ hai khi có thể. Ghi rõ nền tảng và ngày kiểm tra. Không gọi một cụm là trend hiện tại chỉ vì nó xuất hiện trong danh sách cũ hoặc kết quả tìm kiếm.
- Nếu người dùng xin toàn bộ danh sách, nhóm từ theo giai đoạn, ngôn ngữ, sắc thái và mục đích sử dụng; nêu mốc năm là xấp xỉ. Khi viết kịch bản, chỉ lấy vài cụm thật hợp với cảnh và nhân vật, không chèn cả danh mục vào lời thoại.
- Nếu không có truy cập web, dùng cụm người dùng cung cấp hoặc những cách nói phổ thông trong kho; nói ngắn gọn rằng mức độ thịnh hành chưa được kiểm tra gần thời điểm đăng. Không bịa số lượt xem, mức độ phổ biến hay nguồn gốc.
- Chọn theo tuổi, vùng miền, quan hệ, nghề nghiệp, tính cách và hoàn cảnh nhân vật. Người kể chuyện trò chuyện với khán giả có thể dùng giọng mạng khác với bà mẹ chồng, bác bảo vệ, nhân viên văn phòng hoặc trẻ vị thành niên. Việc một nhân vật lớn tuổi cố bắt trend chỉ dùng như trò đùa khi đó là chủ ý và không biến tuổi tác thành đối tượng chế giễu.
- Với video ngắn, thường chỉ cần 1–3 cụm đáng nhớ cho cả tập; kịch bản dài hơn có thể dùng thêm nếu lời thoại vẫn tự nhiên. Đặt chúng vào đúng phản ứng hoặc tình huống, không rải một cụm ở mọi câu và không để trend lấn át cốt truyện.
- Có thể tạo một câu cửa miệng nguyên bản cho nhân vật: ngắn, dễ nhớ, dễ đọc thành tiếng, hợp tính cách; gieo một lần rồi nhắc lại có duyên khi câu chuyện tạo được điểm rơi. Không hứa câu đó chắc chắn sẽ viral.
- Tách trend mới khỏi tiếng lóng quen hoặc meme đã cũ. Nếu một cụm chỉ được dùng để gợi hoài niệm, đừng gọi nó là trend hiện tại. Không chèn từ đang gây tranh cãi, xúc phạm, miệt thị vùng miền/giới tính hoặc làm nhục nạn nhân chỉ để câu tương tác.
- Giữ TTS dễ đọc: ưu tiên dạng phát âm thành tiếng; giải nghĩa nhanh từ viết tắt hoặc tiếng Anh khi cần. Không để hashtag, dấu cộng, chữ số hay cách viết biến dạng khiến TTS đọc sai lọt vào lời kể. Có thể ghi cách đọc trong chú thích không đọc, rồi dùng cách nói tự nhiên trong phần thoại.
- Nếu trend được kiểm chứng bằng web, đặt cụm sử dụng và ghi chú nguồn/ngày/platform trong mục “Ghi chú trend (không đọc)” sau kịch bản. Không chèn trích dẫn hay ghi chú nguồn vào phần lời thoại.

## 8. Tự đánh giá và chỉnh sửa trước khi trả kịch bản

Với mỗi kịch bản vừa viết hoặc biên tập đáng kể, hãy chạy một lượt biên tập riêng theo `references/script-self-review.md` trước khi trả bản cuối. Chấm dựa trên câu hoặc cảnh cụ thể trong kịch bản, không chấm theo cảm giác chung. Nếu người dùng chỉ yêu cầu đánh giá, hãy đưa điểm và đề xuất mà không tự viết lại.

- Giữ nguyên yêu cầu, ý tưởng, kết thúc và các lựa chọn có chủ đích của người dùng. Không hạ điểm một kết thúc mở, nhịp chậm hoặc giọng kể khác thường nếu đó là dụng ý đã nêu.
- Ngưỡng đạt chung là **trên 90/100, tức tối thiểu 91/100**, không có lỗi nghiêm trọng và hook mở đầu của từng tập video ngắn đạt ít nhất 13/15, trừ khi người dùng chủ ý yêu cầu mở chậm hoặc lặng. Nếu bất kỳ hook nào dưới 13, phải sửa dù tổng điểm cao. Với hook theo cửa sổ thời gian hoặc yêu cầu chấm riêng, từng phần hình ảnh/lời thoại được yêu cầu phải đạt 13/15. Từ 70–90: sửa có mục tiêu. Dưới 70 hoặc có lỗi nghiêm trọng: sửa cấu trúc trước, rồi đánh giá lại. Không nâng điểm để chạm ngưỡng; nếu sau hai lượt sửa vẫn dưới 91, nêu đúng điểm thực tế và đánh dấu chưa đạt.
- Sau mỗi lượt sửa, chấm lại cùng một thang điểm. Tối đa hai lượt sửa; nếu vẫn chưa đạt, trả bản tốt nhất và nói ngắn gọn vấn đề còn lại, không khẳng định là đã đạt chuẩn.
- Lỗi nghiêm trọng gồm: vi phạm yêu cầu quan trọng, mâu thuẫn lớn với chi tiết đã thiết lập, kết thúc không trả được mâu thuẫn chính khi người dùng không yêu cầu kết mở, hoặc vi phạm hướng dẫn an toàn/sự thật trong skill này.
- Mặc định đưa kịch bản hoàn chỉnh lên trước, sau đó tóm tắt trạng thái đạt/chưa đạt. Khi người dùng yêu cầu chấm điểm hoặc bảng điểm, hiển thị đủ từng tiêu chí, điểm tối đa, điểm thực tế và căn cứ ngắn; ghi tổng điểm, điểm hook riêng từng tập, trạng thái theo ngưỡng 91 và tối đa ba ưu tiên sửa. Nếu có cửa sổ thời gian, ghi đúng khoảng đó và điểm hình ảnh/lời thoại riêng. Nếu người dùng yêu cầu duyệt thoại trước JSON, không đưa phiếu điểm trừ khi họ yêu cầu bảng điểm cụ thể. Nếu người dùng chỉ muốn lời thoại, vẫn rà nội bộ nhưng ẩn phiếu chấm. Không trình bày suy luận nội bộ; khi được hỏi, chỉ nêu bằng chứng và đề xuất sửa ngắn gọn.
- Điểm là ước lượng biên tập, không chứng minh kịch bản sẽ viral. Chỉ đánh giá xu hướng hiện tại khi có kiểm tra nguồn gần thời điểm đăng theo hướng dẫn trend ở trên.

## 9. Cách trình bày đầu ra

Mặc định đưa kịch bản hoàn chỉnh lên trước, ngắn gọn và dễ thu âm. Có thể dùng bố cục sau khi hữu ích:

- **Tên tập** — ngắn, gợi chuyện nhưng không giật tít sai.
- **Cảnh 1, Cảnh 2...** — tiêu đề cảnh hoặc ghi chú không đọc, nếu người dùng cần chia cảnh.
- **Lời kể/lời thoại** — phần đọc được, đặt hook ở câu đầu tiên.
- **Ghi chú TTS/thời lượng** — chỉ thêm khi có ích hoặc được yêu cầu; đánh dấu rõ là không đọc.

Nếu người dùng chỉ cần lời thoại, không thêm phân tích dài, dàn ý hay checklist. Nếu họ yêu cầu đánh giá/biên tập, nêu ngắn vấn đề chính rồi đưa bản sửa. Trước khi gửi, tự kiểm tra: mọi tập video ngắn đã có hook cụ thể, khơi tò mò và đạt ít nhất 13/15 chưa; nếu có cửa sổ hook, chỉ chấm hình ảnh/lời thoại trong đúng khoảng và tách điểm chưa; tổng điểm có đạt ít nhất 91/100 theo căn cứ cụ thể không; bảng điểm khi được yêu cầu có đủ từng tiêu chí và ghi trạng thái đạt/chưa đạt không; lời hứa mở đầu từng tập có khác móc kết tập sang phần sau không; cảnh có nối nhau bằng nguyên nhân hoặc hệ quả không; lời kể nghe xuôi tai không; các nhân vật có giọng và động cơ riêng không; lời thoại có subtext, giàu nhạc tính và độ dài tự nhiên theo nhân vật và tình huống, không bị cắt cụt hoặc kéo dài máy móc; từng cảnh 10 giây có động lực giữ chân (tiết lộ/leo thang/bẻ lái) và kết tập có cliffhanger sắc bén chưa; hài hước có đúng chỗ không; twist, CTA và social proof có căn cứ và cần thiết không; lượt đọc liên tục có mạch lạc, từng câu phản ứng với câu chuyện trước đó không; cue có khớp cách diễn mà không dựa vào tốc độ từ cố định không; với cảnh 10 giây, mỗi cảnh đã có thoại, tổng thời gian im lặng có không quá 3 giây và từng cue có mốc riêng khớp nhịp nói chưa; các chi tiết nhạy cảm có được xử lý tôn trọng không.
