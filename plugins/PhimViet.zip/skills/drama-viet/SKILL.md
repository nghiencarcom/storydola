---
name: drama-viet
description: Use when writing, outlining, continuing, or editing Vietnamese everyday-life drama scripts, narration, or dialogue for short videos, series, or TTS. Especially useful for neighbor conflicts, in-law tension, domestic violence, blended families, workplace drama, infidelity, and other relatable household, relationship, or community stories.
---

# Biên kịch drama đời thường Việt Nam

Viết những câu chuyện giải trí, dễ hiểu và gần gũi với đời sống người Việt. Ưu tiên lời kể có thể đọc thành tiếng hoặc đưa vào TTS ngay, nhân vật có lý do hành động, tình tiết nối nhau tự nhiên và cảm xúc đọng lại sau câu chuyện.

## 1. Hiểu yêu cầu và chọn hướng viết

- Giữ nguyên ý tưởng, nhân vật, kết thúc và chi tiết mà người dùng đã chốt. Nếu họ đưa bản nháp, hãy sửa đúng mục tiêu thay vì tự đổi chủ đề.
- Xác định định dạng, khán giả, nền tảng, độ dài, giọng kể, số tập và kiểu kết thúc nếu người dùng đã nêu. Nếu thiếu, tự chọn phương án phù hợp và nói rõ giả định ngắn gọn khi nó ảnh hưởng đến kết quả.
- Mặc định có thể viết một tập video ngắn độc lập, kể bằng tiếng Việt phổ thông pha khẩu ngữ vừa phải. Không hỏi dồn một danh sách thông tin; chỉ hỏi khi thiếu dữ kiện khiến không thể chọn hướng truyện hợp lý.
- Với chuỗi tập, giữ một sổ liên tục nội bộ về tuổi, quan hệ, cách xưng hô, mong muốn, bí mật, sự kiện đã xảy ra và các chi tiết còn dang dở. Không tự ý đổi tính cách hay làm mất vật chứng, lời hứa, mốc thời gian đã thiết lập.
- Có thể đưa thêm một câu hỏi tương tác hoặc lời mời theo dõi khi hợp với câu chuyện. Không ép CTA, twist, lời bình của người kể hay bằng chứng xã hội vào mọi tập.

## 2. Dựng câu chuyện và nhịp giữ chân

1. **Mở bằng hook ngay câu đầu.** Nêu một tình huống lạ, một lỗi sắp gây hậu quả, một câu nói khó đỡ, một lựa chọn gây tranh luận, một câu hỏi gợi tò mò hoặc hé lộ một phần kết quả. Hook phải đúng với nội dung tập và gợi ra điều người xem sẽ được biết; không hứa quá mức hay đánh lừa.
2. **Cho người xem hiểu nhanh ai, ở đâu, muốn gì.** Giới thiệu nhân vật và hoàn cảnh bằng hành động, lời kể hoặc đối thoại tự nhiên; tránh phần dẫn giải dài trước khi xung đột bắt đầu.
3. **Tăng xung đột theo quan hệ nhân quả.** Mỗi hiểu lầm, sai lầm hoặc quyết định làm tình hình thay đổi. Cho nhân vật phản ứng hợp với điều họ biết lúc đó; không tạo biến cố chỉ để kéo dài kịch bản.
4. **Kết nối các cảnh.** Mỗi cảnh có một điểm giữ chú ý riêng: thông tin mới, thay đổi cảm xúc, một quyết định, câu hỏi chưa giải đáp, hậu quả đang tới hoặc chi tiết dẫn tự nhiên sang cảnh sau. “Hook cảnh” không có nghĩa cảnh nào cũng phải giật gân. Cảnh sau nên tiếp nối điều vừa xảy ra, cho thấy hệ quả hoặc mở ra lựa chọn kế tiếp.
5. **Đưa câu chuyện tới một kết quả có ý nghĩa.** Có thể giải quyết mâu thuẫn chính, để nhân vật trả giá, cho hai bên hiểu nhau hơn hoặc kết bằng cliffhanger có gieo mầm từ trước. Nếu kết mở, tập vẫn cần có một thay đổi hoặc phát hiện khiến người xem thấy đã nhận được điều gì đó.
6. **Rà lại phần gieo và gặt.** Twist cần được gợi trước và làm thay đổi cách hiểu sự việc; không dùng cú lật vô cớ. Tránh kết luận đạo lý dài dòng. Khi phù hợp, kết bằng một câu hỏi tranh luận bám sát lựa chọn của nhân vật.

Với chuyện nhiều tập, mỗi tập nên giải quyết một nút nhỏ đồng thời để lại một câu hỏi hoặc hệ quả mới. Không cắt ngang giả tạo ngay giữa câu chỉ để tạo cliffhanger.

## 3. Nhân vật, chất Việt và hài hước

- Cho mỗi nhân vật chính một mong muốn cụ thể, một điểm mù hoặc nỗi lo, và cách nói riêng. Nhân vật có thể ích kỷ, khó chịu hay sai nhưng cần có lý do dễ hiểu; tránh biến cả nhóm thành một người tốt và một kẻ ác phẳng lì.
- Xây mâu thuẫn từ chuyện người xem dễ nhận ra: ranh giới riêng tư, tiền bạc, việc nhà, thể diện, lời đồn, trông con, tiếng ồn, hiểu lầm trong nhóm chat hoặc khác biệt thế hệ. Chọn chi tiết phù hợp địa phương và hoàn cảnh đã nêu; đừng gom mọi định kiến vùng miền, nghề nghiệp, giới tính hay tầng lớp vào một nhân vật.

### Drama công sở và quan hệ tình cảm

- Với drama công sở, có thể khai thác chia việc, tranh công, bị quên ghi nhận đóng góp, đổi ca, deadline, thiên vị, đồn đoán hoặc hiểu lầm trong nhóm chat. Làm rõ vị trí, quyền hạn và điều mỗi người muốn. Nếu có quấy rối, bắt nạt hay phân biệt đối xử, không biến người bị hại thành trò cười.
- Với ngoại tình hoặc phản bội, tập trung vào niềm tin, lựa chọn, ranh giới và hệ quả. Cho nhân vật có động cơ riêng mà không đánh đồng lỗi của các bên. Không dùng xâm phạm riêng tư, phát tán ảnh thân mật, bạo lực hay trả thù làm phần thưởng hoặc lời khuyên.

### Kho đề tài đời thường để gợi ý

Chọn một vài mâu thuẫn hợp với nhân vật; đây là kho gợi ý, không phải mô tả rằng gia đình hay cộng đồng Việt nào cũng giống nhau.

- Gia đình nhiều thế hệ: chăm cha mẹ lớn tuổi, tiền sinh hoạt, việc nhà, nuôi dạy con, anh chị em, con riêng, chia tài sản/thừa kế, giỗ chạp hoặc tiền phúng viếng.
- Hàng xóm và nơi ở: tiếng ồn, thú cưng, rác, chỗ đỗ xe, hành lang và khu vực chung, phí sinh hoạt, nhóm chat cư dân, chủ nhà-người thuê, tiền cọc hoặc ở ghép.
- Trường học và phụ huynh: quỹ lớp, thu chi thiếu rõ ràng, quà cáp, hoạt động lớp, áp lực thành tích, hiểu lầm trong nhóm chat và cách người lớn xử lý bắt nạt.
- Công sở: chia việc, ghi nhận công sức, đổi ca, phe nhóm, lời đồn, quản lý thiên vị, áp lực thời hạn và ranh giới giữa đồng nghiệp.
- Tình cảm: ngoại tình, người cũ, ghen tuông, tiền chung, lời hứa, tha thứ hay chia tay và cách cùng chăm con sau đổ vỡ.
- Mua bán và đời sống số: livestream, lời quảng bá, chốt đơn, hàng giao khác kỳ vọng, đổi trả, đánh giá, bình luận lan truyền và chuyện riêng bị đưa lên mạng.
- Cưới hỏi, ma chay, Tết và việc cộng đồng: tiền mừng/phúng viếng, phân công chuẩn bị, chuyện thăm hỏi, đóng góp hoặc khác biệt phong tục giữa các gia đình. Chỉ dùng chi tiết phong tục khi hợp bối cảnh; không coi một cách làm là chuẩn chung cho mọi vùng.
- Tạo hài bằng quan sát đời thường, tương phản, nhịp ngắt, lời nói nước đôi, sự tự tin sai chỗ, hiểu lầm hợp lý và chi tiết quay lại đúng lúc. Hãy để tình huống hoặc tính cách tạo tiếng cười; không cần biến mọi câu thành câu đùa.
- Tranh cãi nên đến từ lựa chọn mà mỗi bên có lý lẽ, hệ quả và giới hạn riêng. Không bịa sự thật, kích động thù ghét hay cố tình làm nhục một nhóm người chỉ để câu bình luận.
- Dùng xưng hô nhất quán theo tuổi tác, quan hệ, vùng miền và giọng nhân vật. Các cách gọi như “mình”, “mấy bà”, “mấy anh em”, “mấy bác” hợp với người kể đang trò chuyện trực tiếp với khán giả; không tự động nhét chúng vào mọi nhân vật. Những cách gọi tạo màu sắc như “bổn tọa”, “ngộ”, “tại hạ”, “lão phu”, “bần đạo”, “bần tăng” chỉ dùng khi hợp vai hoặc là một nét hài có chủ ý. Không trộn tùy tiện khiến người nghe khó hiểu.
- Ưu tiên tiếng Việt phổ thông, câu ngắn, từ quen thuộc. Có thể dùng khẩu ngữ hoặc phương ngữ theo yêu cầu, nhưng vừa đủ để tạo sắc thái và không làm khán giả ngoài vùng khó theo dõi.

## 4. Chủ đề tổn thương và nhân vật dễ bị tổn thương

Có thể viết về bạo lực gia đình, trẻ em, con riêng/con ghẻ, bắt nạt, kiểm soát hoặc xung đột gia đình. Giữ thái độ tôn trọng và để hành vi gây hại có hậu quả rõ ràng.

- Không biến bạo lực, sợ hãi, thương tích hoặc sự bất lực của nạn nhân thành punchline, trò câu view hay bằng chứng rằng người gây hại “thương quá hóa ghen”. Không lãng mạn hóa việc kiểm soát, đe dọa hoặc ép buộc.
- Nếu cần chất hài, đặt nó ở sự vụng về, thói sĩ diện, lời đồn hoặc tình huống phụ; không nhắm vào nạn nhân hay trẻ em. Có thể cho nhân vật bị hại giữ tiếng nói, tìm hỗ trợ và đưa ra lựa chọn an toàn theo mạch truyện.
- Tránh miêu tả bạo lực đồ họa không cần thiết. Không dùng tổn thương của trẻ em như một chi tiết gây sốc đơn thuần.
- Nếu người dùng lấy cảm hứng từ người thật, không tự thêm cáo buộc như sự thật; nên hư cấu hóa và bỏ chi tiết nhận dạng riêng tư khi cần.

## 5. Viết lời kể và lời thoại cho TTS

- Viết như một người đang kể lại câu chuyện cho người khác nghe. Đưa lời thoại trực tiếp vào mạch kể tự nhiên, phân biệt rõ ai đang nói bằng tên hoặc nhịp nói khi cần.
- Dùng câu vừa ngắn, mỗi câu chủ yếu mang một ý. Ưu tiên từ quen thuộc, chủ thể rõ, đại từ nhất quán và quan hệ nhân-quả dễ nghe. Giải thích nhanh từ địa phương hoặc chi tiết văn hóa nếu người ngoài bối cảnh có thể không hiểu.
- Dùng dấu chấm, phẩy, hỏi và chấm lửng để điều khiển nhịp đọc; đừng lạm dụng dấu chấm than, chữ in hoa, emoji, ký hiệu hoặc viết tắt khó phát âm.
- Tách tiêu đề cảnh, chỉ dẫn dựng, âm thanh và ghi chú diễn xuất khỏi phần lời đọc. Nếu cần nhiều giọng TTS, đặt tên người nói ở đầu dòng; nếu cần một giọng kể duy nhất, chuyển nhãn vai thành lời dẫn hoặc lời thoại trong ngoặc kép cho trôi chảy.
- Không để các cụm như “[cười]”, “[nhạc căng thẳng]” lọt vào phần văn bản đọc. Đặt chúng trong mục ghi chú sản xuất riêng hoặc bỏ nếu không cần.
- Dùng mức khoảng **3 từ/giây** làm điểm xuất phát để ước lượng thời lượng, không coi đó là quota. Nhịp nhanh/chậm còn tùy giọng đọc, cảm xúc, dấu ngắt và tốc độ TTS; ưu tiên dễ nghe. Nếu nêu thời lượng, ghi là ước tính và điều chỉnh theo bản audio thực tế. Không nhồi chữ hoặc kéo câu để đạt phép tính.

## 6. Sự thật, social proof và nội dung sản phẩm

- Với quảng cáo hoặc nội dung phi hư cấu, chỉ thêm social proof như số liệu, đánh giá khách hàng, lời chứng thực hay mức độ phổ biến khi người dùng cung cấp căn cứ có thể kiểm tra. Không tự chế khảo sát, doanh số, giấy phép, chứng nhận, chuyên gia hay trải nghiệm khách hàng. Trong truyện hư cấu, lời đồn hoặc ý kiến đám đông có thể là tình tiết, nhưng không trình bày chúng như testimonial hay dữ kiện ngoài đời thật.
- Với thực phẩm chức năng và sản phẩm tương tự, không tự tuyên bố chữa, điều trị, phòng bệnh, bảo đảm kết quả hoặc hiệu quả tuyệt đối. Chỉ dùng nội dung có căn cứ trong tài liệu người dùng cung cấp. Từ “hỗ trợ” không tự làm cho một tuyên bố trở thành có căn cứ; nếu thiếu tài liệu, bỏ tuyên bố đó hoặc hỏi xin nguồn trước khi đưa vào kịch bản.
- Không tự khẳng định sản phẩm đã được cấp phép, kiểm nghiệm, chứng minh lâm sàng hay đáp ứng quy định nếu không có giấy tờ trong ngữ cảnh. Không biến nội dung quảng bá thành lời kể trải nghiệm thật nếu trải nghiệm đó không được cung cấp.
- CTA, lời bình cá nhân và twist là lựa chọn biên tập. Chỉ dùng khi chúng hợp giọng kể và có ích cho câu chuyện.


## 7. Dùng trend và tiếng lóng có chọn lọc

Khi người dùng muốn “bắt trend”, dùng từ lóng hoặc tăng chất mạng xã hội, hãy mở `references/trend-vocabulary.md` để chọn cách dùng và `references/trend-bank-2005-2026.md` để tra kho từ/cụm tiếng Việt, quốc tế và meme theo giai đoạn. Kho từ là tư liệu rộng, không phải bảng xếp hạng trend hiện tại.

- Nếu yêu cầu nói rõ “đang hot”, “trend tuần này/tháng này” hoặc chỉ một nền tảng/nhóm tuổi, kiểm tra nguồn gần thời điểm đăng trên đúng nền tảng và ở Việt Nam. Ưu tiên bài đăng/video gần đây có tương tác thực, trang theo dõi xu hướng hoặc bài tổng hợp có ngày cập nhật; đối chiếu thêm nguồn thứ hai khi có thể. Ghi rõ nền tảng và ngày kiểm tra. Không gọi một cụm là trend hiện tại chỉ vì nó xuất hiện trong danh sách cũ hoặc kết quả tìm kiếm.
- Nếu người dùng xin toàn bộ danh sách, nhóm từ theo giai đoạn, ngôn ngữ, sắc thái và mục đích sử dụng; nêu mốc năm là xấp xỉ. Khi viết kịch bản, chỉ lấy vài cụm thật hợp với cảnh và nhân vật, không chèn cả danh mục vào lời thoại.
- Nếu không có truy cập web, dùng cụm người dùng cung cấp hoặc những cách nói phổ thông trong kho; nói ngắn gọn rằng mức độ thịnh hành chưa được kiểm tra gần thời điểm đăng. Không bịa số lượt xem, mức độ phổ biến hay nguồn gốc.
- Chọn theo tuổi, vùng miền, quan hệ, nghề nghiệp, tính cách và hoàn cảnh nhân vật. Người kể chuyện trò chuyện với khán giả có thể dùng giọng mạng khác với bà mẹ chồng, bác bảo vệ, nhân viên văn phòng hoặc trẻ vị thành niên. Việc một nhân vật lớn tuổi cố bắt trend chỉ dùng như trò đùa khi đó là chủ ý và không biến tuổi tác thành đối tượng chế giễu.
- Với video ngắn, thường chỉ cần 1–3 cụm đáng nhớ cho cả tập; kịch bản dài hơn có thể dùng thêm nếu lời thoại vẫn tự nhiên. Đặt chúng vào đúng phản ứng hoặc tình huống, không rải một cụm ở mọi câu và không để trend lấn át cốt truyện.
- Có thể tạo một câu cửa miệng nguyên bản cho nhân vật: ngắn, dễ nhớ, dễ đọc thành tiếng, hợp tính cách; gieo một lần rồi nhắc lại có duyên khi câu chuyện tạo được điểm rơi. Không hứa câu đó chắc chắn sẽ viral.
- Tách trend mới khỏi tiếng lóng quen hoặc meme đã cũ. Nếu một cụm chỉ được dùng để gợi hoài niệm, đừng gọi nó là trend hiện tại. Không chèn từ đang gây tranh cãi, xúc phạm, miệt thị vùng miền/giới tính hoặc làm nhục nạn nhân chỉ để câu tương tác.
- Giữ TTS dễ đọc: ưu tiên dạng phát âm thành tiếng; giải nghĩa nhanh từ viết tắt hoặc tiếng Anh khi cần. Không để hashtag, dấu cộng, chữ số hay cách viết biến dạng khiến TTS đọc sai lọt vào lời kể. Có thể ghi cách đọc trong chú thích không đọc, rồi dùng cách nói tự nhiên trong phần thoại.
- Nếu trend được kiểm chứng bằng web, đặt cụm sử dụng và ghi chú nguồn/ngày/platform trong mục “Ghi chú trend (không đọc)” sau kịch bản. Không chèn trích dẫn hay ghi chú nguồn vào phần lời thoại.

## 8. Cách trình bày đầu ra

Mặc định đưa kịch bản hoàn chỉnh lên trước, ngắn gọn và dễ thu âm. Có thể dùng bố cục sau khi hữu ích:

- **Tên tập** — ngắn, gợi chuyện nhưng không giật tít sai.
- **Cảnh 1, Cảnh 2...** — tiêu đề cảnh hoặc ghi chú không đọc, nếu người dùng cần chia cảnh.
- **Lời kể/lời thoại** — phần đọc được, đặt hook ở câu đầu tiên.
- **Ghi chú TTS/thời lượng** — chỉ thêm khi có ích hoặc được yêu cầu; đánh dấu rõ là không đọc.

Nếu người dùng chỉ cần lời thoại, không thêm phân tích dài, dàn ý hay checklist. Nếu họ yêu cầu đánh giá/biên tập, nêu ngắn vấn đề chính rồi đưa bản sửa. Trước khi gửi, tự kiểm tra: hook có thật sự mở câu chuyện không; cảnh có nối nhau bằng nguyên nhân hoặc hệ quả không; lời kể nghe xuôi tai không; các nhân vật có giọng và động cơ riêng không; hài hước có đúng chỗ không; twist, CTA và social proof có căn cứ và cần thiết không; lời thoại có phù hợp TTS không; các chi tiết nhạy cảm có được xử lý tôn trọng không.
