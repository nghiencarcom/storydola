# Phiếu tự đánh giá kịch bản — PhimViet

Dùng phiếu này sau khi viết hoặc biên tập đáng kể một kịch bản. Chấm điểm trên bản đang đọc; mỗi điểm trừ phải gắn với một cảnh, câu hoặc chi tiết cụ thể. Dùng tiêu chí theo yêu cầu của người dùng thay vì áp một công thức cho mọi thể loại.

| Tiêu chí | Điểm tối đa | Kiểm tra |
|---|---:|---|
| Bám yêu cầu, thể loại, khán giả và định dạng | 10 | Đúng ngôn ngữ, độ dài gần mục tiêu, tiền đề và các chi tiết đã chốt. |
| Hook và lời hứa mở đầu | 15 | Mở đầu tạo tò mò, đúng với câu chuyện và được trả lời hoặc phát triển. |
| Xung đột và mức độ leo thang | 15 | Quyết định hoặc hiểu lầm làm tình hình thay đổi; hệ quả tăng hợp lý. |
| Logic, nhân quả và tính liên tục | 15 | Hành động phù hợp điều nhân vật biết; thời gian, quan hệ, vật chứng và sự kiện không tự mâu thuẫn. |
| Nhân vật thuyết phục và hợp bối cảnh Việt | 15 | Động cơ dễ hiểu; xưng hô, địa phương, quan hệ và hoàn cảnh phù hợp, không dựa vào định kiến. |
| Nhịp kể và khả năng giữ chân | 15 | Mỗi cảnh có thay đổi, hệ quả hoặc thông tin mới; không lặp ý hay kéo dài vô ích. |
| Lời thoại, độ tự nhiên và độ sẵn sàng cho TTS | 10 | Câu dễ nghe, rõ người nói, từ ngữ dễ phát âm; ghi chú sản xuất tách khỏi lời đọc. |
| Cao trào và payoff kết thúc | 5 | Mâu thuẫn chính có kết quả; twist hoặc cliffhanger đã được gieo, trừ khi người dùng muốn kết mở khác. |
| **Tổng** | **100** | |

## Quy tắc chấm và sửa

- Chấm mỗi mục bằng số nguyên từ 0 đến điểm tối đa: điểm tối đa khi tiêu chí được đáp ứng rõ; điểm giữa khi còn một điểm yếu cụ thể; điểm thấp khi thiếu hoặc mâu thuẫn. Không cộng điểm chỉ vì văn bản dài hay nhiều tình tiết.
- Ghi tối đa ba vấn đề ưu tiên, kèm vị trí trong kịch bản và một hướng sửa ngắn. Sửa những vấn đề đó, không đổi tiền đề, kết thúc hoặc yêu cầu đã được người dùng chốt.
- Không coi nhịp chậm, kết mở, hài khô hoặc nhân vật khó chịu là lỗi nếu đó là lựa chọn có chủ đích và phù hợp yêu cầu.
- Đánh dấu lỗi nghiêm trọng khi kịch bản vi phạm yêu cầu quan trọng, có mâu thuẫn lớn với sự kiện đã thiết lập, không trả mâu thuẫn chính dù người dùng không yêu cầu kết mở, hoặc trình bày tuyên bố thật/trend hiện tại thiếu căn cứ như sự thật.
- Theo ngưỡng và giới hạn số lượt sửa trong skill chính. Sau hai lượt sửa, trả bản tốt nhất cùng vấn đề còn lại nếu chưa đạt; không lặp viết lại vô hạn.

## Ghi chú đầu ra

Mặc định chỉ hiển thị tổng điểm, một đến ba chỉnh sửa chính và vấn đề còn lại nếu có. Chỉ đưa toàn bộ phiếu chấm khi người dùng yêu cầu đánh giá chi tiết. Điểm này là nhận định biên tập nội bộ, không dự báo lượt xem hay mức độ viral.
