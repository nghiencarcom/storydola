# Phiếu tự đánh giá kịch bản — PhimViet

Dùng phiếu này sau khi viết hoặc biên tập đáng kể một kịch bản. Chấm điểm trên bản đang đọc; mỗi điểm trừ phải gắn với một cảnh, câu hoặc chi tiết cụ thể. Dùng tiêu chí theo yêu cầu của người dùng thay vì áp một công thức cho mọi thể loại.

| Tiêu chí | Điểm tối đa | Kiểm tra |
|---|---:|---|
| Bám yêu cầu, thể loại, khán giả và định dạng | 10 | Đúng ngôn ngữ, độ dài gần mục tiêu, tiền đề và các chi tiết đã chốt. |
| Hook và lời hứa mở đầu | 15 | Chấm một hoặc hai câu thoại đầu và nhịp mở cảnh của từng tập theo độ rõ, xung đột/cái giá cụ thể, tò mò, độ tự nhiên và lời hứa được tập đó thực hiện. Dùng thang neo bên dưới; không cộng điểm chỉ vì gây sốc, có dấu hỏi hay nói lớn. |
| Xung đột và mức độ leo thang | 15 | Quyết định hoặc hiểu lầm làm tình hình thay đổi; hệ quả tăng hợp lý. |
| Logic, nhân quả và tính liên tục | 15 | Hành động phù hợp điều nhân vật biết; thời gian, quan hệ, vật chứng và sự kiện không tự mâu thuẫn. |
| Nhân vật thuyết phục và hợp bối cảnh Việt | 10 | Động cơ dễ hiểu; xưng hô, địa phương, quan hệ và hoàn cảnh phù hợp, không dựa vào định kiến. |
| Nhịp kể và khả năng giữ chân | 10 | Mỗi cảnh có thay đổi, hệ quả hoặc thông tin mới; không lặp ý hay kéo dài vô ích. |
| Chia lượt thoại và thời lượng từng cue | 10 | Khi yêu cầu cue có thời lượng, tách đúng lượt người nói và tính thời lượng theo số từ, nhịp đọc, cách diễn, khoảng nghỉ. Không lặp một thời lượng cố định cho các câu khác nhau nếu không có lý do; giữ cue trong cảnh và khớp ghi chú dựng được yêu cầu. Nếu không yêu cầu thời gian, đánh giá cách tách lượt thoại mà không bắt buộc có timecode. |
| Mạch thoại, độ tự nhiên và độ sẵn sàng cho TTS | 10 | Đọc liên tục không cần tiêu đề cảnh vẫn mạch lạc; mỗi câu phản ứng với diễn biến trước và thể hiện ý muốn/cảm xúc; cảnh chuyển tự nhiên; ý lặp có dụng ý; câu dễ phát âm và ghi chú dựng nằm ngoài lời đọc. |
| Cao trào và payoff kết thúc | 5 | Mâu thuẫn chính có kết quả; twist hoặc cliffhanger đã được gieo, trừ khi người dùng muốn kết mở khác. |
| **Tổng** | **100** | |

## Quy tắc chấm và sửa

- Chấm bản cuối sau khi sửa, không chấm ý tưởng hoặc bản nháp đầu. Với mỗi tiêu chí, ghi câu/cảnh cụ thể làm căn cứ cho điểm và từng điểm bị trừ. Chỉ cho tối đa khi mọi yêu cầu của mục đều có bằng chứng; dùng khoảng 75% điểm tối đa cho lỗi nhẹ, 50% cho điểm yếu rõ, 25% khi phần lớn chưa đạt và 0 khi thiếu hoặc mâu thuẫn. Dùng số nguyên, cộng đúng các hàng và không tự giả định ưu điểm chưa có trong bản. Không trừ hai lần cùng một lỗi nếu nó không gây ra hai vấn đề riêng. Không cộng điểm chỉ vì bài dài, giật gân hay nhiều tình tiết.
- Ngưỡng đạt chung là **trên 90/100 (tối thiểu 91/100)**, không có lỗi nghiêm trọng; hook của từng tập video ngắn phải đạt ít nhất 13/15, trừ khi người dùng chủ ý yêu cầu mở chậm/lặng. Chấm riêng từng tập; sau tối đa hai lượt sửa, nếu tổng điểm hoặc hook vẫn dưới ngưỡng thì ghi điểm thật, nêu điểm yếu còn lại và đánh dấu “chưa đạt”, không nâng điểm cho đẹp.
- Ghi tối đa ba vấn đề ưu tiên, kèm vị trí trong kịch bản và một hướng sửa ngắn. Sửa những vấn đề đó, không đổi tiền đề, kết thúc hoặc yêu cầu đã được người dùng chốt.
- Không coi nhịp chậm, kết mở, hài khô hoặc nhân vật khó chịu là lỗi nếu đó là lựa chọn có chủ đích và phù hợp yêu cầu.
- Đánh dấu lỗi nghiêm trọng khi kịch bản vi phạm yêu cầu quan trọng, có mâu thuẫn lớn với sự kiện đã thiết lập, không trả mâu thuẫn chính dù người dùng không yêu cầu kết mở, hoặc trình bày tuyên bố thật/trend hiện tại thiếu căn cứ như sự thật.
- Theo ngưỡng 91/100 và giới hạn số lượt sửa trong skill chính. Sau hai lượt sửa, trả bản tốt nhất cùng điểm thực tế và vấn đề còn lại nếu chưa đạt; không lặp viết lại vô hạn.

## Thang neo chấm hook mở đầu — 15 điểm

Chấm một hoặc hai câu thoại đầu/nhịp hình mở cảnh, không chấm tên tập hay tiết lộ xuất hiện về sau. Cộng điểm từ năm phần:

- **Rõ ngay (0–3):** người xem hình dung được chuyện gì đang xảy ra mà không cần đoạn dẫn dài.
- **Xung đột hoặc cái giá cụ thể (0–4):** có lựa chọn, mất mát, mâu thuẫn hay hệ quả khiến người xem quan tâm.
- **Tò mò (0–3):** mở ra một câu hỏi cụ thể cần được giải đáp; tránh câu chung chung kiểu “không thể tin nổi” hoặc đe dọa mơ hồ.
- **Tự nhiên khi nói (0–2):** ngắn gọn, hợp nhân vật, dễ nghe; không như khẩu hiệu hay phần thuyết minh.
- **Lời hứa đáng tin/payoff (0–3):** tập phim phát triển hoặc trả lại điều câu mở gợi ra; không đánh lừa.

Dùng tổng điểm để hiệu chuẩn: **13–15** cuốn hút, cụ thể ở gần hết các mặt; **10–12** rõ nhưng còn một nhược điểm đáng kể; **7–9** hiểu được nhưng chung chung, ít hệ quả hoặc phải giải thích thêm; **4–6** chủ yếu là dẫn giải, khó hiểu hoặc hứa mà chưa có căn cứ; **0–3** không có hook dùng được hoặc mở đầu đánh lạc hướng. Hook dưới 13 cần sửa với video ngắn, trừ khi người dùng chủ ý chọn cách mở chậm/lặng.

## Chấm hook theo cửa sổ: hình ảnh và lời thoại

Thực hiện cho mọi tập video ngắn trong lượt tự đánh giá, không cần người dùng nhắc. Chấm riêng hình ảnh và lời thoại, mỗi phần trên thang 15 điểm. Chỉ dùng chi tiết nhìn/nghe được trong khoảng yêu cầu; nếu không nêu khoảng, mặc định là 0–5 giây. Nếu câu hoặc cảnh kéo qua ranh giới thời gian, chỉ chấm phần nằm trong khoảng. Với định dạng không có timecode, xét nhịp mở cảnh và một hoặc hai câu thoại đầu. Điểm một phần không bù cho phần còn lại; kênh cố ý vắng mặt thì ghi N/A. Chỉ dùng nội dung phía sau để xác nhận lời hứa mở đầu có trung thực hay không, không tính nội dung đó thành bằng chứng cho hook.

Neo điểm **hình ảnh**: nhìn hiểu ngay (0–3); có hành động/xung đột/cái giá cụ thể (0–4); gợi câu hỏi bằng hình (0–3); hình ảnh rõ và có chi tiết riêng (0–2); khớp lời hứa/payoff thật của tập (0–3). Neo điểm **lời thoại** dùng năm phần trong thang chấm hook ở trên. Ghi đúng khoảng thời gian cùng căn cứ ngắn cho mỗi điểm. Mỗi phần được yêu cầu/có mặt dưới 13/15 phải sửa, trừ khi người dùng chủ ý mở lặng/chậm.

Với chuỗi nhiều tập, chấm hook mở đầu riêng từng tập. Đầu tập là lời hứa cho chính tập đó; móc cuối tập để dẫn sang tập sau là một điểm đánh giá riêng, không cộng vào điểm hook mở đầu.

## Ghi chú đầu ra

Khi người dùng yêu cầu chấm điểm hoặc bảng điểm, hiển thị bảng đầy đủ: từng tiêu chí, điểm thực tế/điểm tối đa và căn cứ ngắn gắn với cảnh/câu cụ thể. Ghi tổng điểm, hook từng tập, trạng thái “đạt” (từ 91/100, không có lỗi nghiêm trọng và đạt cổng hook) hoặc “chưa đạt”, cùng tối đa ba ưu tiên sửa. Khi duyệt theo cửa sổ, nêu đúng khoảng thời gian và điểm hình ảnh/lời thoại riêng. Khi lời thoại là trọng tâm, nêu thêm điểm mạch thoại trên 10; nếu có cue thời gian, nêu điểm chia cue/thời lượng trên 10. Nếu người dùng yêu cầu duyệt thoại trước JSON, không hiển thị phiếu điểm trừ khi họ yêu cầu bảng điểm cụ thể; chỉ đưa thoại chữ và ghi chú im lặng rồi chờ. Điểm này là nhận định biên tập, không dự báo lượt xem hay mức độ viral.

## Cue thời gian và khoảng im lặng

- Với cảnh 10 giây trong phim thoại, tổng thời gian không có lời thoại tối đa là 3 giây mỗi cảnh, tính cả phần đầu, khoảng nghỉ giữa các lượt và phần đuôi. Nhạc, hiệu ứng và tiếng nền không thay thế lời thoại.
- Mỗi cảnh 10 giây phải có ít nhất một lượt thoại, trừ khi người dùng chủ ý yêu cầu cảnh im lặng. Ghi mốc thời gian tương đối trong cảnh cho từng người nói và từng lượt thoại; thời lượng cue phải dựa trên số từ, tốc độ, diễn xuất và khoảng nghỉ, không lặp máy móc.
- Kiểm tra bằng phép tính: cộng mọi khoảng không có lời thoại trong cảnh và xác nhận tổng không quá 3 giây; từng cue không vượt 3 từ/giây và toàn bộ cue không vượt thời lượng cảnh. Nếu không thể giữ cả lời thoại tự nhiên lẫn giới hạn, báo rõ và đề xuất rút gọn hoặc đổi thời lượng cảnh.
