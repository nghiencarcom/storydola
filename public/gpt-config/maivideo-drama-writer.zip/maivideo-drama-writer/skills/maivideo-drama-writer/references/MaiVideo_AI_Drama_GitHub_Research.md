# Khảo sát GitHub cho MaiVideo AI Drama

Khảo sát ngày 20/11/2026. Tiêu chí chọn gồm độ sát với một công đoạn biên kịch, khả năng áp dụng cho drama tiếng Việt và tương thích luồng dựng StoryAI.

| Nguồn | Áp dụng cho MaiVideo | Điều chỉnh theo StoryAI |
| --- | --- | --- |
| [awesome-short-drama-skills](https://github.com/UnderleveledBuilder/awesome-short-drama-skills) | Tra cứu theo công đoạn, đọc thử nghiệm so sánh với nhóm đối chứng | Đánh giá theo brief và thể loại. Benchmark tập viết dùng một model sinh và giám khảo AI. Thứ hạng có thể thay đổi theo cách chấm hook và theo thể loại. |
| [narrative-to-screen-reader](https://github.com/zhlmi/narrative-to-screen-reader) | Đánh giá chất liệu nào giữ được khi chuyển lên màn hình | Chuyển đoạn nội tâm thành hành vi, dấu vết và hệ quả, ưu tiên điểm nhìn đã có. |
| [shuohao-skills](https://github.com/eternityspring/shuohao-skills) | Handoff từ hồ sơ nhân vật, chuyển thể, bối cảnh và đạo cụ đến kịch bản | Dùng hồ sơ hình ảnh và schema hiện có của StoryAI. |
| [screenwriting-skills](https://github.com/jtydhr88/screenwriting-skills) | Chẩn đoán cấu trúc, nhịp cảnh, động cơ và thoại | Áp dụng linh hoạt vào tập ngắn và giữ điểm rơi theo thời lượng thật. |
| [drama-skills](https://github.com/zenstory-ai/drama-skills) | Tham khảo thoại ngắn, giọng riêng và cảm xúc qua đồ vật | Giữ sắc thái thoại Việt và kiểm tra sức nặng của điểm kết. |
| [emma-screenwriting-skills](https://github.com/adoria111/emma-screenwriting-skills) | Theo dõi quyền biết, nấc bằng chứng và cái giá của chiến thắng | Chỉ ghi các đầu mối có tác động đến cảnh hoặc tập kế. |
| [screenwriter-skill](https://github.com/Vi7QY/screenwriter-skill) | Review có tiêu chí và đề xuất sửa theo lỗi | Tách lượt biên tập nội dung và lượt kiểm tra import, ưu tiên lỗi ảnh hưởng cao. |
| [ManjuForge](https://github.com/mengxiujie/ManjuForge) | Lưu trạng thái và kiểm tra nhất quán xuyên tập | Dùng bible và handoff sẵn có, ghi thêm ai biết gì và dự định trả đầu mối ở đâu. |
| [novel-to-ai-short-drama-skill](https://github.com/muxia0396/novel-to-ai-short-drama-skill) | Nhìn cảnh từ góc độ diễn xuất, blocking và thời lượng | Căn theo clip 5/10/15 giây và ảnh mở đầu của StoryAI. |

Playbook và plugin do MaiVideo tổng hợp bằng lời mới. Các repo được dùng làm tài liệu tham khảo, không đóng gói mã, prompt hoặc tài nguyên từ upstream.
