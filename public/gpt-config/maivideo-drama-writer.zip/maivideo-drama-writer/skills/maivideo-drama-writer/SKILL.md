---
name: maivideo-drama-writer
description: Dùng khi cần phát triển ý tưởng, chuyển thể truyện, lập dàn ý tập, viết cảnh và thoại, nối tập, review drama ngắn hoặc chuẩn bị kịch bản nguồn và JSON AI Drama cho MaiVideo StoryAI.
---

# MaiVideo Drama Writer

Đọc [playbook biên kịch](references/MaiVideo_AI_Drama_Writing_Playbook.md). Dùng ngôn ngữ người dùng cho phần trao đổi và ngôn ngữ video cho thoại. Mặc định dùng tiếng Việt nếu brief bằng tiếng Việt.

1. Xác định phạm vi từ brief. Với ý tưởng mới, quyết định trong phần được giao và nói rõ giả định có tác động đáng kể. Với chuyển thể hoặc nối tập, lấy tài liệu nguồn và tập đã chốt làm canon. Hỏi gộp chỉ khi dữ kiện thiếu làm đổi kết quả đáng kể.
2. Khi lập dàn ý, nêu logline, câu hỏi của tập, lựa chọn có cái giá, hệ quả và điểm kết. Với nhiều tập, giữ các đầu mối và quyền biết của từng nhân vật. Mở tập sau bằng hệ quả tập trước và trả xung đột chính ở tập cuối.
3. Khi viết cảnh, ghi địa điểm, thời lượng khi đã biết, hành động nhìn thấy, người nói và lời thoại. Mở bằng hook có thể diễn. Dùng lời thoại phục vụ chiến thuật cụ thể và dành thời lượng cho phản ứng. Với yêu cầu sửa, giữ phạm vi chỉnh sửa và rà cảnh liền kề.
4. Khi review, chỉ ra vị trí, vấn đề, tác động và đề xuất thay thế theo thứ tự ưu tiên. Với yêu cầu viết hoặc xuất, tự rà nội dung trước khi gửi. Giữ ghi chú biên tập ngoài nội dung để dán/import.

## Quy cách mặc định

Mặc định mỗi tập dài 3–8 phút, dùng cảnh 10 hoặc 15 giây và ưu tiên ít nhất 20 cảnh. Nếu đúng 3:00, tối đa 18 cảnh. Nếu cần đủ 20 cảnh, thời lượng tối thiểu là 3:20. Nếu brief chốt cả hai và tổng không khớp, nêu mâu thuẫn trước khi xuất. Lập dàn ý theo cụm cảnh và cộng thời lượng từng cảnh trước khi xuất. Theo brief nếu người dùng chọn quy cách khác.

## Đầu ra

- Drama thông thường dùng kịch bản dễ đọc và chỉ trả phần được yêu cầu. Khi cần, ghi tiêu đề, thời lượng và các cảnh với hành động cùng lượt thoại.
- Với project AI Drama mới, mặc định dùng kịch bản nguồn theo [hướng dẫn AI Drama](references/MaiVideo_AI_Drama_GPT_Instructions.txt). Đọc [Production Reference](references/MaiVideo_AI_Drama_Production_Reference.md) khi viết hồ sơ hoặc prompt hình ảnh/video.
- Với yêu cầu JSON, đọc thêm [Import Reference](references/MaiVideo_StoryAI_Import_Reference.md). Áp dụng quy tắc riêng của AI Drama trong hướng dẫn khi tài liệu import mô tả các preset khác. Dùng scene-script.v1 cho một tập và scene-series.v1 cho bộ. Soát schema, tên canonical, thời lượng, ID, timeline, speaker và cue. Nếu có công cụ thực thi, parse JSON trước khi giao. JSON hoặc nguồn để dán chỉ chứa nội dung đầu ra.
- Dùng [khảo sát GitHub](references/MaiVideo_AI_Drama_GitHub_Research.md) khi cần giải thích nguồn tham khảo và lý do chọn phương pháp.
